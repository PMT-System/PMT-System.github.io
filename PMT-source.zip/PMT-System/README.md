# PMT — Project, APK and QA workspace

**Status: local implementation for review. Not a deployed or fully verified production system.**

16 October 2026: the existing Supabase schema was inspected read-only. Automatic approval review rejected the proposed live upgrade because it changes existing policies, grants and constraints. No database upgrade or Edge Function deployment has been performed. The repository was cloned; these changes have not been pushed. Do not publish this frontend against the unchanged database.

## Is package mein kya hai

- Static HTML/CSS/JavaScript frontend; no production package dependency or paid API required for core records.
- Supabase email/password login, refresh, logout, recovery and password change.
- Project/application forms, membership management and team accounts through an Admin-only backend action.
- APK metadata, upload progress, SHA-256, APK container validation, exact build downloads, build history and QA assignment.
- Bug reporting, database-generated IDs, immutable reported date/time, Pakistan-time display, comments, evidence, controlled status updates, retest history and developer queue.
- Persistent text chat: company-wide Full Team, one channel per project, and private 1-to-1 conversations. Current active membership is enforced by proposed RLS; 1-to-1 messages have no Admin read bypass in the application.
- Full CSV export across all matching pages: bug fields plus comments, evidence references, assignment/status/retest history in JSON columns.
- Versioned QA summaries: write text or attach PDF/TXT/CSV/DOCX. AI output is reviewed before saving.
- Gemini and Groq adapters, approved-provider fallback, per-user hourly guard, chunk checkpoints and resume for summary generation. Other providers are not implemented or automatically enabled.
- Reviewed SQL upgrade files, schema-only baseline, manual GitHub Pages workflow, executable tests and honest verification results.

## Architecture

Browser → GitHub Pages static files → Supabase Auth / REST / RLS.

Sensitive operations → authenticated `pmt-service` Edge Function → service-only database actions, private Storage, company Google Drive or approved AI endpoints. The service validates the user's actual Auth token and active database profile on every request. An unauthenticated public function gateway does **not** mean unauthenticated application operations.

`projects → applications → builds → build_assignments/test_sessions`

`bugs → affected_build_id / fixed_build_id → bug_retests`

`bugs → comments / attachments / assignments / status_history`

Reports stay in the database when an APK binary is removed. Latest two available APKs per app and APKs in active testing/retest are protected by the removal procedure. Old APK removal requires an Admin reason and explicit confirmation. Audit records cannot be edited by ordinary browser roles.

## Files

| File | Purpose |
|---|---|
| `index.html`, `styles.css` | Responsive interface and content security policy |
| `app.js` | Integrated workflows |
| `chat.js`, `backend/chat.sql` | Persistent chat UI, channel provisioning and access policies |
| `backend/chat-tests.sql` | Executed in local PostgreSQL/WASM with isolated fixtures |
| `api.js` | Authenticated REST, uploads and short-lived downloads |
| `utils.js` | CSV, dates, validation, pagination and hashing |
| `config.js` | Supabase URL and public publishable key only |
| `backend/baseline.sql` | Schema-only reconstruction for an empty Supabase database; never run on the existing project |
| `backend/release.sql` and its component SQL files | Proposed changes for existing project; require approval and integration testing |
| `backend/functions/pmt-service/` | Server implementation; no credentials included |
| `.github/workflows/pages.yml` | Manual deployment, publishes only seven frontend files |
| `tests/` | Unit and isolated service tests |
| `tools/browser-check.cjs` | Fixture browser workflows; requires Playwright and Edge |
| `VERIFICATION.md` | Results, blockers and outstanding requirements |

## Existing project setup — approval required

1. Existing Supabase project: `ylwdxcresqbwriifsfik`. Existing tables and Admin profile were found. A private application-data backup was saved outside the repository; no Auth passwords were exported.
2. First make a database backup. Schema SQL alone is **not** a data backup. Preserve Auth, Storage files and sequence values separately.
3. Review the combined changes in `backend/release.sql`. Approval is needed because they replace bug visibility policy, revoke direct workflow writes, add protected file fields, private buckets and service-only operations. Existing reports are not deleted.
4. After explicit approval, apply the combined release.sql as one transaction, then run the live role/security matrix in `VERIFICATION.md`. These scripts are one-time migrations; do not rerun them blindly.
5. The release adds a resolution-cycle reference to require a retest for the current fix. The change is implemented in SQL but not live verified.
6. Deploy the `pmt-service` function with `index.ts` and its local `utils.js`. Set `verify_jwt=false` only because the handler itself calls Auth `/user` and validates the active profile. Do not deploy a variant without that check.
7. Supabase **Authentication → URL Configuration**: Site URL `https://pmt-system.github.io/`; add that exact URL to Redirect URLs. Disable public user sign-up for this company tool. Recovery/invite emails require suitable SMTP; built-in development email delivery is not a production team email solution.
8. The existing Admin signs in using their own password. It is never placed in the repository. If creating an empty replacement project, create the first Auth user in the dashboard and promote its profile to Admin from the trusted SQL editor after checking its UUID. Browser registration must never set roles.

## Backend secrets

Supabase dashboard → **Edge Functions → Secrets**. Never send private keys in chat or put them in `config.js`.

| Secret | Value |
|---|---|
| `APP_ORIGIN` | `https://pmt-system.github.io` (origin, no repository path) |
| Supabase runtime secrets | `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` normally supplied by the runtime |
| `GOOGLE_CLIENT_ID` | Company Google OAuth client ID |
| `GOOGLE_CLIENT_SECRET` | Matching OAuth client secret |
| `GOOGLE_REFRESH_TOKEN` | Offline OAuth token belonging to the authorized company Drive account |
| `GOOGLE_DRIVE_FOLDER_ID` | Private company APK folder |
| `AI_PROVIDERS` | Ordered array described below |

Google Drive is not connected by the chat's Drive connector. Create a company Google Cloud project, enable Drive API, configure OAuth consent and obtain offline authorization with the narrowest suitable file permissions. Use the same authorized application for the folder and APK uploads. Avoid public sharing. OAuth testing-mode refresh token expiry and Drive storage quotas must be resolved before relying on the integration. Real resumable browser upload/CORS and download streaming still require end-to-end testing with the company's credentials.

`AI_PROVIDERS` is an ordered JSON array. Each enabled entry requires `type` (`gemini` or `groq`), `model` (a currently available free-tier model chosen in that provider account), `key` (the real API key), `enabled: true`, and `freeOnly: true`. No model or secret placeholder is used as working functionality. An empty array leaves AI unavailable while manual reports continue working.

**The `freeOnly` flag is an Admin declaration, not a provider billing control.** Keep each provider account on its free plan with no paid billing enabled. The app cannot guarantee no charge if an Admin connects an account that bills for requests. Quotas and model availability change. The chain skips rate-limited/unavailable providers; it does not create more accounts or bypass limits. All approved providers may receive the report text. Review each provider's data policy first. No external AI calls were made during verification.

Summary generation uses up to 120,000 characters, broken into saved 10,000-character sections. A larger report is rejected explicitly, not silently truncated. Drafts are stored in `ai_jobs`, and summary retry resumes saved sections. AI never approves releases, closes bugs or persists a bug without QA approval.

## Free-tier constraints (checked 16 October 2026)

- Supabase Free: 500 MB database, 1 GB file storage, 5 GB egress plus a separate 5 GB cached egress allowance, 50,000 MAU; inactivity pausing after one week. Automatic backups and leaked-password protection are not included in the free plan. See [pricing](https://supabase.com/pricing).
- Supabase Free file upload maximum is 50 MB. APKs above the implemented conservative 50,000,000-byte threshold go directly to Drive. Small files use Supabase if tracked Storage usage is below the application's 900 MB safety threshold. Existing failed/orphan uploads may consume quota and need Admin review. See [file limits](https://supabase.com/docs/guides/storage/uploads/file-limits).
- A 200 MB APK downloaded 25 times is roughly 5 GB transferred. Storage capacity alone does not determine whether this workload fits free allowances.
- Keeping two APKs per app at 200 MB means about 400 MB per app. Google Drive also has finite account storage shared with other Google services; it is not unlimited or an application backup.
- GitHub Pages serves only static frontend files. It does not keep your backend secrets or enforce company data access. The public code is visible; the data must be secured by Auth/RLS. Published site size and bandwidth/build limits apply. See [Pages limits](https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits).
- Gemini free-tier data handling and Groq free-plan limits need company approval. See [Gemini pricing](https://ai.google.dev/gemini-api/docs/pricing) and [Groq rate limits](https://console.groq.com/docs/rate-limits).

## GitHub Pages deployment — after live verification

1. Do not publish until backend migration, Edge Function and role tests pass.
2. Push the reviewed files to `https://github.com/PMT-System/PMT-System.github.io` using an authorized account. A repository URL alone does not provide write credentials. No push was attempted in this run.
3. Repository **Settings → Pages → Source → GitHub Actions**.
4. **Actions → Publish PMT frontend → Run workflow**. It runs tests and uploads only frontend files (including chat.js). Backend SQL, scripts and tests are excluded from the website artifact (but remain visible in a public source repository).
5. The expected project URL is `https://pmt-system.github.io/`. This is a target URL, not a verified live deployment. All frontend assets are relative to support that subpath.
6. Verify real login/logout/recovery, protected data, APK upload/download, QA testing, bug lifecycle, report CSV, Drive and AI using the test matrix before company rollout.

## Daily use

**Admin:** Create project → application → team accounts → project memberships. Assign each build to QA. Assign bugs to developers. Review Not a Bug disputes. Approve old APK file removals. Manage account roles/access and inspect audit history.

**Developer:** Sign in → authorized project → Builds → Upload APK. Use a new version code for every build. My Queue → inspect bug/evidence → comment or mark In Progress/Pending/Not a Bug. For Ready for Retest, give resolution notes and choose a different registered build from the same app.

**QA:** Review assigned build → download exact APK → record testing result. Report a bug in English or write Roman Urdu and request an AI draft. Check all details, then Approve & Save. Attach screenshot/video after the bug exists. Retest the linked fixed build, record notes, then pass/close or fail/reopen. Final QA Summaries accepts written reports and uploaded documents, with separate saved versions.

**Reports:** Full bug CSV contains all matching authorized records and their histories; it includes private attachment references, not permanent public links. CSV cells are escaped to reduce spreadsheet formula injection. Reports can contain company data; store exports in approved company locations.

## Backup and recovery

Before each migration, export the full PostgreSQL schema and data using Supabase-supported database backup tooling/CLI. Export the Auth user configuration appropriately; report CSV alone cannot restore accounts, relationships or sequence state. Record the bug sequence's current value so restored IDs cannot collide. Download Storage objects and private Drive APKs separately with an authorized account. Keep a manifest of build ID, storage provider/path, checksum and removal status. Store backups outside the same account, encrypted as company policy requires. Never include backend secrets in a public archive.

Test restore in an isolated non-production environment within an approved budget. Do not assume free automatic backups exist. APK file deletion is permanent and does not delete reports; recover a deleted binary only from a separately retained backup.

## Local verification

Node 22.18+ or Node 24: `npm test`, `npm run check`, `npm start`.

The browser script uses an environment-specific bundled Playwright path; edit its require path when running elsewhere. Fixture data is only in tests and is never injected into the production application. Screenshots explicitly contain fixture users/projects and are not evidence of a live deployment.

## Team chat

Sidebar → Chat. Full Team includes Admin-approved active company accounts. New accounts created by the Admin backend are approved; for an existing teammate use Team → Manage → Company chat access. Unknown public sign-ups default to no chat access. Project conversations use the project’s current members, with Admin oversight. Choose a colleague to open a private 1-to-1 channel; repeated opens reuse the same pair. Text messages have server dates/times and persist in the database. Messages refresh every 10 seconds only while Chat is open and the browser tab is visible. Load older messages retrieves previous history in pages of 50. Draft text survives navigation in the same tab; failed sends retain the draft, and a retry reconciles the message nonce to avoid duplicates. No paid chat service is used. Text messages count toward Supabase database/request/egress quotas. Chat attachments, calls and read receipts are outside this addition.

This module has been tested using fixtures, not the live database. `backend/chat-tests.sql` covers sender spoofing, outsider access, removed project members, inactive users and non-participant Admin access to DMs in an isolated test database. It passed in the local PostgreSQL/WASM harness; live Supabase checks remain blocked. Chat SQL is included in the updated combined `backend/release.sql`; do not apply it separately to bypass the pending release approval.

## Deployment attempt update

The user authorized autonomous deployment. Automatic approval review still rejected the live combined migration, including after local PostgreSQL tests and an empty-project preflight. No live schema or Edge Function changes were made. Existing application data was backed up outside this repository. Local database tests passed baseline restore, complete migration, Admin preservation, chat isolation and bug workflow security. PGlite is a pinned development-only dependency; production frontend has no package dependency.

The repository was renamed through GitHub settings to `PMT-System.github.io` at the user’s request for a clean URL. Target site: `https://pmt-system.github.io/`. Repository rename does not publish a website.
