-- Reviewed release: after retest-hardening.sql.
begin;
alter table public.builds add column archived_previous_status text;
alter table public.projects add column archived_previous_status text;
alter table public.applications add column archived_at timestamptz;
alter table public.bugs add column archived_at timestamptz;
alter table public.qa_summaries add column archived_at timestamptz;
revoke update on public.bugs from authenticated;
grant update(title,description,device_model,android_version,steps_to_reproduce,actual_result,expected_result,qa_notes,severity,priority,original_report) on public.bugs to authenticated;
commit;
