-- Revoked-project and inactive-account hardening; tested locally only.
begin;
CREATE OR REPLACE FUNCTION public.pmt_review_not_a_bug(p_bug_id uuid, p_accept boolean, p_reason text)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare b public.bugs%rowtype;
begin
 if auth.uid() is null or not (public.pmt_is_admin() or
  (public.pmt_is_qa() and exists(select 1 from public.bugs x where x.id=p_bug_id and x.reported_by=auth.uid() and public.pmt_app_member(x.application_id))))
 then raise exception 'QA reporter or Admin authorization required' using errcode='42501'; end if;
 if nullif(btrim(coalesce(p_reason,'')),'') is null then raise exception 'Review reason required'; end if;
 select * into b from public.bugs where id=p_bug_id for update;
 if not found or b.status<>'not_a_bug' then raise exception 'Bug is not awaiting Not a Bug review'; end if;
 if p_accept then
  insert into public.activity_logs(actor_id,bug_id,event_type,new_data)
  values(auth.uid(),p_bug_id,'not_a_bug_accepted',jsonb_build_object('reason',p_reason));
  return 'not_a_bug';
 end if;
 update public.bugs set status='reopened',updated_at=now() where id=p_bug_id;
 insert into public.bug_status_history(bug_id,changed_by,from_status,to_status,reason)
 values(p_bug_id,auth.uid(),'not_a_bug','reopened',p_reason);
 insert into public.activity_logs(actor_id,bug_id,event_type,new_data)
 values(auth.uid(),p_bug_id,'not_a_bug_rejected',jsonb_build_object('reason',p_reason));
 if b.assigned_developer_id is not null then
  insert into public.notifications(recipient_id,event_type,bug_id,message)
  values(b.assigned_developer_id,'bug_reopened',p_bug_id,'QA/Admin rejected Not a Bug decision');
 end if;
 return 'reopened';
end $function$;
drop policy pmt_read_notifications on public.notifications;
create policy pmt_read_notifications on public.notifications for select to authenticated using((public.pmt_is_admin() or recipient_id=auth.uid()) and (public.pmt_is_admin() or public.pmt_is_qa() or public.pmt_is_dev()));
drop policy pmt_user_notification_readmark on public.notifications;
create policy pmt_user_notification_readmark on public.notifications for update to authenticated using(recipient_id=auth.uid() and (public.pmt_is_admin() or public.pmt_is_qa() or public.pmt_is_dev())) with check(recipient_id=auth.uid() and (public.pmt_is_admin() or public.pmt_is_qa() or public.pmt_is_dev()));
commit;
