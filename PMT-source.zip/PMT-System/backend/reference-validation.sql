-- Append-only summary version consistency and private evidence references.
begin;
create or replace function public.pmt_validate_summary_reference() returns trigger language plpgsql set search_path='' as $$
begin
 if new.supersedes_id is not null and not exists(select 1 from public.qa_summaries where id=new.supersedes_id and project_id=new.project_id) then raise exception 'Previous summary must belong to the same project'; end if;
 if new.storage_path is not null and (split_part(new.storage_path,'/',1)<>new.project_id::text or split_part(new.storage_path,'/',2)<>new.author_id::text) then raise exception 'Invalid private report file reference'; end if;
 return new;
end $$;
create trigger pmt_summary_reference before insert on public.qa_summaries for each row execute function public.pmt_validate_summary_reference();
create or replace function public.pmt_validate_evidence_reference() returns trigger language plpgsql set search_path='' as $$
begin
 if split_part(new.storage_path,'/',1)<>new.bug_id::text or split_part(new.storage_path,'/',2)<>new.uploaded_by::text then raise exception 'Invalid evidence file reference'; end if;
 return new;
end $$;
create trigger pmt_evidence_reference before insert on public.bug_attachments for each row execute function public.pmt_validate_evidence_reference();
commit;
