-- Current-resolution-cycle retest enforcement. Apply after additional.sql.
begin;
alter table public.bugs add column resolution_cycle uuid not null default gen_random_uuid();
alter table public.bug_retests add column resolution_cycle uuid;
CREATE OR REPLACE FUNCTION public.pmt_change_bug_status(p_bug_id uuid, p_status text, p_reason text DEFAULT NULL::text, p_fixed_build_id uuid DEFAULT NULL::uuid)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare b public.bugs%rowtype; admin boolean; qa boolean; dev boolean; v_next_qa uuid;
begin
 if auth.uid() is null then raise exception 'Login required' using errcode='42501'; end if;
 select * into b from public.bugs where id=p_bug_id for update;
 if not found then raise exception 'Bug not found'; end if;
 admin:=public.pmt_is_admin();qa:=public.pmt_is_qa();dev:=public.pmt_is_dev();
 if p_status not in ('in_progress','pending','not_a_bug','ready_for_retest','reopened','closed')
 then raise exception 'Invalid status transition target'; end if;
 if b.status='closed' then raise exception 'Closed bug cannot be modified without authorized reopen procedure'; end if;
 if not (
  (p_status in ('in_progress','pending','not_a_bug','ready_for_retest') and (admin or (dev and b.assigned_developer_id=auth.uid() and public.pmt_app_member(b.application_id))))
  or (p_status in ('reopened','closed') and (admin or (qa and public.pmt_app_member(b.application_id))))
 ) then raise exception 'Not authorized for this status' using errcode='42501'; end if;
 if p_status in ('in_progress','pending','not_a_bug','ready_for_retest') and b.status not in ('open','reopened','in_progress','pending','not_a_bug') then raise exception 'Bug must first be reopened or assigned'; end if;
 if p_status in ('pending','not_a_bug','ready_for_retest') and nullif(trim(coalesce(p_reason,'')),'') is null then raise exception 'Reason or resolution notes required'; end if;
 if p_status='ready_for_retest' then
  if p_fixed_build_id is null or not exists(select 1 from public.builds f where f.id=p_fixed_build_id and f.application_id=b.application_id and f.id<>b.affected_build_id and f.file_state='available') then
  raise exception 'Valid fixed build from the same application required'; end if;
 end if;
 if p_status in ('closed','reopened') then
  if b.status<>'ready_for_retest' then raise exception 'Bug must be ready for retest'; end if;
  if not exists(select 1 from public.bug_retests t where t.bug_id=b.id and t.build_id=b.fixed_build_id and t.resolution_cycle=b.resolution_cycle and t.id=(select latest.id from public.bug_retests latest where latest.bug_id=b.id and latest.resolution_cycle=b.resolution_cycle order by latest.retested_at desc,latest.id desc limit 1) and
    t.outcome=case when p_status='closed' then 'passed' else 'failed' end)
  then raise exception 'Matching QA retest result required'; end if;
 end if;
 update public.bugs set status=p_status,
 pending_reason=case when p_status in ('pending','not_a_bug') then p_reason else pending_reason end,
 resolution_notes=case when p_status='ready_for_retest' then p_reason else resolution_notes end,
 resolution_cycle=case when p_status='ready_for_retest' then gen_random_uuid() else resolution_cycle end,
 fixed_build_id=case when p_status='ready_for_retest' then p_fixed_build_id else fixed_build_id end,
 closed_at=case when p_status='closed' then now() else closed_at end,
 updated_at=now() where id=p_bug_id;
 insert into public.bug_status_history(bug_id,changed_by,from_status,to_status,reason) values(p_bug_id,auth.uid(),b.status,p_status,p_reason);
 insert into public.activity_logs(actor_id,bug_id,event_type,old_data,new_data) values(auth.uid(),p_bug_id,'bug_status_changed',jsonb_build_object('status',b.status),jsonb_build_object('status',p_status,'fixed_build_id',p_fixed_build_id));
 if p_status='ready_for_retest' then
   select ba.qa_user_id into v_next_qa from public.build_assignments ba where ba.build_id=p_fixed_build_id and ba.revoked_at is null order by ba.assigned_at desc limit 1;
   if v_next_qa is not null then insert into public.notifications(recipient_id,event_type,bug_id,build_id,message) values(v_next_qa,'bug_ready_for_retest',p_bug_id,p_fixed_build_id,'Bug is ready for QA retesting'); end if;
 elsif p_status in ('reopened','closed') and b.assigned_developer_id is not null then
   insert into public.notifications(recipient_id,event_type,bug_id,message) values(b.assigned_developer_id,'bug_'||p_status,p_bug_id,'Bug marked '||p_status);
 end if;
 return p_status;
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_submit_retest(p_bug_id uuid, p_build_id uuid, p_outcome text, p_notes text DEFAULT NULL::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare b public.bugs%rowtype; v_id uuid;
begin
 if auth.uid() is null or not (public.pmt_is_qa() or public.pmt_is_admin()) then raise exception 'QA/Admin required' using errcode='42501'; end if;
 select * into b from public.bugs where id=p_bug_id for update;
 if not found or b.status<>'ready_for_retest' or b.fixed_build_id is distinct from p_build_id then raise exception 'Bug not awaiting this build retest'; end if;
 if p_outcome not in ('passed','failed','blocked') then raise exception 'Invalid retest result'; end if;
 if not public.pmt_is_admin() and (not public.pmt_app_member(b.application_id) or not exists(
  select 1 from public.build_assignments ba where ba.build_id=p_build_id and ba.qa_user_id=auth.uid() and ba.revoked_at is null))
 then raise exception 'QA is not assigned to fixed build' using errcode='42501'; end if;
 insert into public.bug_retests(bug_id,build_id,qa_user_id,outcome,notes,resolution_cycle) values(p_bug_id,p_build_id,auth.uid(),p_outcome,p_notes,b.resolution_cycle) returning id into v_id;
 insert into public.activity_logs(actor_id,bug_id,build_id,event_type,new_data) values(auth.uid(),p_bug_id,p_build_id,'bug_retested',jsonb_build_object('outcome',p_outcome,'notes',p_notes));
 return v_id;
end $function$
;
commit;

