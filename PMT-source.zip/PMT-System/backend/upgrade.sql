-- Additive upgrade for the existing PMT-System database. Preserve historical records.
begin;
create schema if not exists pmt_private;
revoke all on schema pmt_private from public,anon,authenticated;
alter table public.builds drop constraint builds_storage_provider_check;
alter table public.builds add constraint builds_storage_provider_check check(storage_provider in ('supabase','google_drive'));
alter table public.builds add column storage_path text, add column file_removed_at timestamptz, add column file_removed_by uuid references public.profiles(id), add column file_state text not null default 'available' check(file_state in ('available','deleting','removed'));
alter table public.build_files drop constraint build_files_provider_check;
alter table public.build_files add constraint build_files_provider_check check(provider in ('supabase','google_drive'));
alter table public.bugs add column original_report text;
create table public.qa_summaries(
 id uuid primary key default gen_random_uuid(),project_id uuid not null references public.projects(id),
 title text not null check(length(btrim(title))>0),body text not null default '',storage_path text,file_name text,
 author_id uuid not null references public.profiles(id),created_at timestamptz not null default now(),
 supersedes_id uuid references public.qa_summaries(id),ai_generated boolean not null default false
);
alter table public.qa_summaries enable row level security;
grant select,insert on public.qa_summaries to authenticated;
create policy summary_read on public.qa_summaries for select to authenticated using(public.pmt_is_admin() or public.pmt_project_member(project_id));
create policy summary_insert on public.qa_summaries for insert to authenticated with check(author_id=auth.uid() and (public.pmt_is_admin() or (public.pmt_is_qa() and public.pmt_project_member(project_id))));
create table public.upload_jobs(
 id uuid primary key, user_id uuid not null references public.profiles(id),application_id uuid not null references public.applications(id),
 metadata jsonb not null,provider text not null,provider_path text,drive_file_id text,
 state text not null default 'pending',created_at timestamptz not null default now(),build_id uuid references public.builds(id)
);
alter table public.upload_jobs enable row level security;
revoke all on public.upload_jobs from anon,authenticated;
create table public.ai_jobs(
 id uuid primary key default gen_random_uuid(),user_id uuid not null references public.profiles(id),project_id uuid references public.projects(id),
 kind text not null check(kind in ('bug','summary')),input text not null,result text,provider text,state text not null default 'pending',created_at timestamptz not null default now()
);
alter table public.ai_jobs enable row level security;
grant select on public.ai_jobs to authenticated;
create policy ai_read on public.ai_jobs for select to authenticated using(user_id=auth.uid() or public.pmt_is_admin());
create table pmt_private.ai_limits(user_id uuid primary key,window_start timestamptz not null default now(),requests int not null default 0);
alter table pmt_private.ai_limits enable row level security;
grant all on public.upload_jobs,public.ai_jobs to service_role;
grant usage on schema pmt_private to service_role;
grant all on all tables in schema pmt_private to service_role;

-- Limit developer bug visibility, including comments, histories, evidence, and RPCs.
create or replace function public.pmt_bug_member(bug uuid) returns boolean language sql stable security definer set search_path='' as $$
 select auth.uid() is not null and exists(select 1 from public.bugs b where b.id=bug and public.pmt_app_member(b.application_id) and (public.pmt_is_qa() or (public.pmt_is_dev() and b.assigned_developer_id=auth.uid())))
$$;
drop policy pmt_read_bugs on public.bugs;
create policy pmt_read_bugs on public.bugs for select to authenticated using(public.pmt_is_admin() or public.pmt_bug_member(id));
create or replace function public.pmt_guard_report_time() returns trigger language plpgsql set search_path='' as $$
begin
 if tg_op='INSERT' then new.created_at=now();
 elsif new.created_at is distinct from old.created_at then raise exception 'Reported date/time is immutable'; end if;
 return new;
end $$;
create trigger pmt_bugs_reported_time before insert or update on public.bugs for each row execute function public.pmt_guard_report_time();

-- Deny direct workflow fabrication, including INSERT status/assignment bypass.
drop policy pmt_admin_build_assignments on public.build_assignments;
drop policy pmt_admin_bug_assignments on public.bug_assignments;
drop policy pmt_admin_activity_logs_insert on public.activity_logs;
drop policy pmt_admin_bug_status_history_insert on public.bug_status_history;
revoke insert,update,delete on public.build_assignments,public.bug_assignments,public.test_sessions,public.bug_retests,public.bug_status_history,public.activity_logs from authenticated;
revoke insert,update,delete on public.build_files from authenticated;
revoke insert on public.builds from authenticated;
revoke update on public.notifications from authenticated;
grant update(is_read) on public.notifications to authenticated;
create or replace function public.pmt_guard_bug_insert() returns trigger language plpgsql set search_path='' as $$
begin
 if current_user='authenticated' then
  if new.status<>'open' or new.fixed_build_id is not null or new.closed_at is not null or new.assigned_developer_id is not null or new.reported_by is distinct from auth.uid() then raise exception 'New bugs must start open and unassigned'; end if;
 end if;
 return new;
end $$;
create trigger pmt_bug_insert_guard before insert on public.bugs for each row execute function public.pmt_guard_bug_insert();
create or replace function public.pmt_guard_build_identity() returns trigger language plpgsql set search_path='' as $$
begin
 if current_user='authenticated' and (new.storage_provider is distinct from old.storage_provider or new.storage_path is distinct from old.storage_path or new.file_state is distinct from old.file_state or new.file_removed_at is distinct from old.file_removed_at or new.file_removed_by is distinct from old.file_removed_by or new.file_size is distinct from old.file_size or new.file_checksum is distinct from old.file_checksum) then raise exception 'Use the secure file management action'; end if;
 return new;
end $$;
create trigger pmt_build_identity before update on public.builds for each row execute function public.pmt_guard_build_identity();
create policy qa_edit_own_bug on public.bugs for update to authenticated using(public.pmt_is_qa() and reported_by=auth.uid() and public.pmt_bug_member(id)) with check(public.pmt_is_qa() and reported_by=auth.uid() and public.pmt_bug_member(id));

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values
 ('apks','apks',false,50000000,array['application/vnd.android.package-archive','application/octet-stream']),
 ('qa-reports','qa-reports',false,10000000,array['application/pdf','text/plain','text/csv','application/vnd.openxmlformats-officedocument.wordprocessingml.document']) on conflict(id) do nothing;
-- APK uploads and downloads are mediated by the authenticated service; no public policy.
create policy report_upload on storage.objects for insert to authenticated with check(bucket_id='qa-reports' and split_part(name,'/',2)=auth.uid()::text and (public.pmt_is_admin() or (public.pmt_is_qa() and public.pmt_project_member(split_part(name,'/',1)::uuid))));
create policy report_read on storage.objects for select to authenticated using(bucket_id='qa-reports' and (public.pmt_is_admin() or public.pmt_project_member(split_part(name,'/',1)::uuid)));
create policy attachment_admin_delete on storage.objects for delete to authenticated using(bucket_id in ('bug-screenshots','bug-videos','qa-reports') and public.pmt_is_admin());

-- Atomic upload finalization, accessible only by the authenticated Edge Function service client.
create or replace function public.pmt_finalize_upload(p_job_id uuid,p_actor uuid) returns uuid language plpgsql security definer set search_path='' as $$
declare j public.upload_jobs%rowtype; b uuid; m jsonb;
begin
 select * into j from public.upload_jobs where id=p_job_id and user_id=p_actor for update;
 if not found then raise exception 'Upload not found'; end if;
 if j.build_id is not null then return j.build_id; end if;
 if j.state<>'verified' then raise exception 'File has not been verified'; end if;
 if not exists(select 1 from public.profiles p where p.id=p_actor and p.is_active and (p.role='admin' or (p.role='developer' and exists(select 1 from public.project_members pm join public.applications a on a.project_id=pm.project_id where a.id=j.application_id and pm.user_id=p_actor)))) then raise exception 'Upload permission revoked'; end if;
 m=j.metadata;
 insert into public.builds(application_id,version_name,version_code,file_name,file_size,storage_provider,drive_file_id,storage_path,file_checksum,release_notes,uploaded_by,previous_build_id)
 values(j.application_id,m->>'version_name',(m->>'version_code')::bigint,m->>'file_name',(m->>'file_size')::bigint,j.provider,j.drive_file_id,j.provider_path,m->>'sha256',m->>'release_notes',p_actor,nullif(m->>'previous_build_id','')::uuid) returning id into b;
 insert into public.build_files(build_id,provider,provider_file_id,original_filename,byte_size,sha256,recorded_by) values(b,j.provider,coalesce(j.drive_file_id,j.provider_path),m->>'file_name',(m->>'file_size')::bigint,m->>'sha256',p_actor);
 update public.upload_jobs set state='complete',build_id=b where id=j.id;
 return b;
end $$;
revoke all on function public.pmt_finalize_upload(uuid,uuid) from public,anon,authenticated;
grant execute on function public.pmt_finalize_upload(uuid,uuid) to service_role;

create or replace function public.pmt_prepare_file_delete(p_build uuid,p_actor uuid,p_reason text) returns jsonb language plpgsql security definer set search_path='' as $$
declare b public.builds%rowtype;
begin
 if not exists(select 1 from public.profiles where id=p_actor and role='admin' and is_active) then raise exception 'Admin required'; end if;
 if length(btrim(p_reason))<5 then raise exception 'Deletion reason required'; end if;
 select * into b from public.builds where id=p_build for update;
 if not found or b.file_state='removed' then raise exception 'File is already removed or missing'; end if;
 if exists(select 1 from (select id from public.builds where application_id=b.application_id and file_state<>'removed' order by created_at desc,id desc limit 2) newest where id=b.id) then raise exception 'Latest two APKs are protected; archive older builds only'; end if;
 if b.status in ('testing','retesting','assigned_to_qa') or exists(select 1 from public.bugs where fixed_build_id=b.id and status='ready_for_retest') then raise exception 'Active QA or retest APK is protected'; end if;
 update public.builds set file_state='deleting' where id=b.id;
 insert into public.activity_logs(actor_id,build_id,event_type,new_data) values(p_actor,b.id,'apk_deletion_approved',jsonb_build_object('reason',p_reason));
 return to_jsonb(b);
end $$;
revoke all on function public.pmt_prepare_file_delete(uuid,uuid,text) from public,anon,authenticated;
grant execute on function public.pmt_prepare_file_delete(uuid,uuid,text) to service_role;

create or replace function public.pmt_ai_reserve(p_actor uuid) returns boolean language plpgsql security definer set search_path='' as $$
declare n int;
begin
 insert into pmt_private.ai_limits(user_id,requests) values(p_actor,1)
 on conflict(user_id) do update set requests=case when pmt_private.ai_limits.window_start<now()-interval '1 hour' then 1 else pmt_private.ai_limits.requests+1 end,window_start=case when pmt_private.ai_limits.window_start<now()-interval '1 hour' then now() else pmt_private.ai_limits.window_start end returning requests into n;
 return n<=20;
end $$;
revoke all on function public.pmt_ai_reserve(uuid) from public,anon,authenticated;
grant execute on function public.pmt_ai_reserve(uuid) to service_role;

create or replace function public.pmt_comment_created_audit() returns trigger language plpgsql security definer set search_path='' as $$
declare b public.bugs%rowtype;
begin
 select * into b from public.bugs where id=new.bug_id;
 insert into public.activity_logs(actor_id,bug_id,event_type,new_data) values(new.author_id,new.bug_id,'bug_comment_added',jsonb_build_object('comment_id',new.id));
 insert into public.notifications(recipient_id,event_type,bug_id,message) select distinct uid,'bug_comment',new.bug_id,'New comment on '||b.bug_code from unnest(array[b.reported_by,b.assigned_developer_id]) uid where uid is not null and uid<>new.author_id;
 return new;
end $$;
-- Privileged trigger functions must not be public RPCs.
revoke execute on function public.pmt_profile_after_signup(),public.pmt_guard_bug_code(),public.pmt_record_creation(),public.pmt_audit_attachment_created(),public.pmt_comment_created_audit() from public,anon,authenticated;
create index qa_summaries_project_idx on public.qa_summaries(project_id,created_at desc);
create index ai_jobs_user_idx on public.ai_jobs(user_id,created_at desc);
commit;

