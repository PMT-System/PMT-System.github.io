-- Isolated PostgreSQL test fixtures. NOT for production execution.
begin;
insert into auth.users(id,email) values
 ('c0000000-0000-4000-8000-000000000001','workflow-admin@example.test'),
 ('c0000000-0000-4000-8000-000000000002','workflow-qa@example.test'),
 ('c0000000-0000-4000-8000-000000000003','workflow-dev-a@example.test'),
 ('c0000000-0000-4000-8000-000000000004','workflow-dev-b@example.test');
update public.profiles set role='admin' where id='c0000000-0000-4000-8000-000000000001';
update public.profiles set role='qa' where id='c0000000-0000-4000-8000-000000000002';
insert into public.projects(id,project_name) values('d0000000-0000-4000-8000-000000000001','Workflow fixture');
insert into public.project_members(project_id,user_id) select 'd0000000-0000-4000-8000-000000000001',id from public.profiles where id in ('c0000000-0000-4000-8000-000000000002','c0000000-0000-4000-8000-000000000003','c0000000-0000-4000-8000-000000000004');
insert into public.applications(id,project_id,app_name,package_name) values('d0000000-0000-4000-8000-000000000002','d0000000-0000-4000-8000-000000000001','Fixture app','test.workflow.app');
insert into public.builds(id,application_id,version_name,version_code,uploaded_by) values
 ('e0000000-0000-4000-8000-000000000001','d0000000-0000-4000-8000-000000000002','1',1,'c0000000-0000-4000-8000-000000000003'),
 ('e0000000-0000-4000-8000-000000000002','d0000000-0000-4000-8000-000000000002','2',2,'c0000000-0000-4000-8000-000000000003');
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"c0000000-0000-4000-8000-000000000002","role":"authenticated"}',true);
insert into public.bugs(id,application_id,affected_build_id,title,reported_by) values('f0000000-0000-4000-8000-000000000001','d0000000-0000-4000-8000-000000000002','e0000000-0000-4000-8000-000000000001','Fixture bug',auth.uid());
do $$begin
 if not exists(select 1 from public.bugs where id='f0000000-0000-4000-8000-000000000001' and bug_code like 'BUG-%') then raise exception 'Bug ID missing'; end if;
 begin
  update public.bugs set created_at='2000-01-01' where id='f0000000-0000-4000-8000-000000000001';
  raise exception 'TEST FAILURE: date mutation allowed';
 exception when insufficient_privilege then null;end;
end $$;
select set_config('request.jwt.claims','{"sub":"c0000000-0000-4000-8000-000000000001","role":"authenticated"}',true);
select public.pmt_assign_bug('f0000000-0000-4000-8000-000000000001','c0000000-0000-4000-8000-000000000003');
select public.pmt_assign_build('e0000000-0000-4000-8000-000000000002','c0000000-0000-4000-8000-000000000002');
select set_config('request.jwt.claims','{"sub":"c0000000-0000-4000-8000-000000000004","role":"authenticated"}',true);
do $$begin
 if exists(select 1 from public.bugs where id='f0000000-0000-4000-8000-000000000001') then raise exception 'Developer B sees Developer A assignment'; end if;
 if exists(select 1 from public.bug_status_history where bug_id='f0000000-0000-4000-8000-000000000001') then raise exception 'Private history leaked'; end if;
end $$;
select set_config('request.jwt.claims','{"sub":"c0000000-0000-4000-8000-000000000003","role":"authenticated"}',true);
do $$begin
 begin perform public.pmt_change_bug_status('f0000000-0000-4000-8000-000000000001','pending',null,null);raise exception 'TEST FAILURE: empty pending reason';exception when others then if sqlerrm not like '%Reason or resolution%' then raise;end if;end;
 begin perform public.pmt_change_bug_status('f0000000-0000-4000-8000-000000000001','ready_for_retest','Fixed',null);raise exception 'TEST FAILURE: missing fixed build';exception when others then if sqlerrm not like '%Valid fixed build%' then raise;end if;end;
end $$;
select public.pmt_change_bug_status('f0000000-0000-4000-8000-000000000001','ready_for_retest','Fixed login','e0000000-0000-4000-8000-000000000002');
select set_config('request.jwt.claims','{"sub":"c0000000-0000-4000-8000-000000000002","role":"authenticated"}',true);
do $$begin
 begin perform public.pmt_change_bug_status('f0000000-0000-4000-8000-000000000001','closed','No retest',null);raise exception 'TEST FAILURE: closed without retest';exception when others then if sqlerrm not like '%Matching QA retest%' then raise;end if;end;
end $$;
select public.pmt_retest_and_transition('f0000000-0000-4000-8000-000000000001','passed','Verified login');
select set_config('request.jwt.claims','{"sub":"c0000000-0000-4000-8000-000000000001","role":"authenticated"}',true);
select public.pmt_reopen_closed_bug('f0000000-0000-4000-8000-000000000001','Regression in next check');
select set_config('request.jwt.claims','{"sub":"c0000000-0000-4000-8000-000000000003","role":"authenticated"}',true);
select public.pmt_change_bug_status('f0000000-0000-4000-8000-000000000001','ready_for_retest','Second fix','e0000000-0000-4000-8000-000000000002');
select set_config('request.jwt.claims','{"sub":"c0000000-0000-4000-8000-000000000002","role":"authenticated"}',true);
do $$begin
 begin perform public.pmt_change_bug_status('f0000000-0000-4000-8000-000000000001','closed','Using old retest',null);raise exception 'TEST FAILURE: stale retest accepted';exception when others then if sqlerrm not like '%Matching QA retest%' then raise;end if;end;
end $$;
select public.pmt_retest_and_transition('f0000000-0000-4000-8000-000000000001','failed','Still broken');
do $$begin
 if not exists(select 1 from public.bugs where id='f0000000-0000-4000-8000-000000000001' and status='reopened') then raise exception 'Failed retest did not reopen';end if;
 if (select count(*) from public.bug_retests where bug_id='f0000000-0000-4000-8000-000000000001')<>2 then raise exception 'Retest history lost';end if;
end $$;
reset role;
delete from public.project_members where project_id='d0000000-0000-4000-8000-000000000001' and user_id='c0000000-0000-4000-8000-000000000003';
update public.profiles set is_active=false where id='c0000000-0000-4000-8000-000000000002';
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"c0000000-0000-4000-8000-000000000003","role":"authenticated"}',true);
do $$begin
 begin perform public.pmt_change_bug_status('f0000000-0000-4000-8000-000000000001','in_progress','Revoked member',null);raise exception 'TEST FAILURE: revoked developer changed bug';exception when insufficient_privilege then null;end;
end $$;
select set_config('request.jwt.claims','{"sub":"c0000000-0000-4000-8000-000000000002","role":"authenticated"}',true);
do $$begin
 if exists(select 1 from public.notifications where recipient_id=auth.uid()) then raise exception 'Inactive QA retained notification access';end if;
end $$;
rollback;
