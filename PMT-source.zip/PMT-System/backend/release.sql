-- Reviewed proposal; live application blocked by automatic approval review.
-- No operational reports are deleted.
begin;
DO $preflight$ BEGIN
 IF (SELECT count(*) FROM public.profiles)<>1 OR EXISTS(SELECT 1 FROM public.projects) OR EXISTS(SELECT 1 FROM public.builds) OR EXISTS(SELECT 1 FROM public.bugs) THEN RAISE EXCEPTION 'Project changed since preflight; stop for review'; END IF;
END $preflight$;
-- upgrade.sql
-- Additive upgrade for the existing PMT-System database. Preserve historical records.

create schema if not exists pmt_private;
revoke all on schema pmt_private from public,anon,authenticated;
alter table public.builds drop constraint builds_storage_provider_check;
alter table public.builds add constraint builds_storage_provider_check check(storage_provider in ('supabase','google_drive'));
alter table public.builds add column storage_path text, add column file_removed_at timestamptz, add column file_removed_by uuid references public.profiles(id), add column file_state text not null default 'available' check(file_state in ('available','deleting','removed'));
alter table public.build_files drop constraint build_files_provider_check;
alter table public.build_files add constraint build_files_provider_check check(provider in ('supabase','google_drive'));
alter table public.bugs add column original_report text;
create table public.qa_summaries(
 id uuid primary key default gen_random_uuid(),project_id uuid not null references public.projects(id),
 title text not null check(length(btrim(title))>0),body text not null default '',storage_path text,file_name text,
 author_id uuid not null references public.profiles(id),created_at timestamptz not null default now(),
 supersedes_id uuid references public.qa_summaries(id),ai_generated boolean not null default false
);
alter table public.qa_summaries enable row level security;
grant select,insert on public.qa_summaries to authenticated;
create policy summary_read on public.qa_summaries for select to authenticated using(public.pmt_is_admin() or public.pmt_project_member(project_id));
create policy summary_insert on public.qa_summaries for insert to authenticated with check(author_id=auth.uid() and (public.pmt_is_admin() or (public.pmt_is_qa() and public.pmt_project_member(project_id))));
create table public.upload_jobs(
 id uuid primary key, user_id uuid not null references public.profiles(id),application_id uuid not null references public.applications(id),
 metadata jsonb not null,provider text not null,provider_path text,drive_file_id text,
 state text not null default 'pending',created_at timestamptz not null default now(),build_id uuid references public.builds(id)
);
alter table public.upload_jobs enable row level security;
revoke all on public.upload_jobs from anon,authenticated;
create table public.ai_jobs(
 id uuid primary key default gen_random_uuid(),user_id uuid not null references public.profiles(id),project_id uuid references public.projects(id),
 kind text not null check(kind in ('bug','summary')),input text not null,result text,provider text,state text not null default 'pending',created_at timestamptz not null default now()
);
alter table public.ai_jobs enable row level security;
grant select on public.ai_jobs to authenticated;
create policy ai_read on public.ai_jobs for select to authenticated using(user_id=auth.uid() or public.pmt_is_admin());
create table pmt_private.ai_limits(user_id uuid primary key,window_start timestamptz not null default now(),requests int not null default 0);
alter table pmt_private.ai_limits enable row level security;
grant all on public.upload_jobs,public.ai_jobs to service_role;
grant usage on schema pmt_private to service_role;
grant all on all tables in schema pmt_private to service_role;

-- Limit developer bug visibility, including comments, histories, evidence, and RPCs.
create or replace function public.pmt_bug_member(bug uuid) returns boolean language sql stable security definer set search_path='' as $$
 select auth.uid() is not null and exists(select 1 from public.bugs b where b.id=bug and public.pmt_app_member(b.application_id) and (public.pmt_is_qa() or (public.pmt_is_dev() and b.assigned_developer_id=auth.uid())))
$$;
drop policy pmt_read_bugs on public.bugs;
create policy pmt_read_bugs on public.bugs for select to authenticated using(public.pmt_is_admin() or public.pmt_bug_member(id));
create or replace function public.pmt_guard_report_time() returns trigger language plpgsql set search_path='' as $$
begin
 if tg_op='INSERT' then new.created_at=now();
 elsif new.created_at is distinct from old.created_at then raise exception 'Reported date/time is immutable'; end if;
 return new;
end $$;
create trigger pmt_bugs_reported_time before insert or update on public.bugs for each row execute function public.pmt_guard_report_time();

-- Deny direct workflow fabrication, including INSERT status/assignment bypass.
drop policy pmt_admin_build_assignments on public.build_assignments;
drop policy pmt_admin_bug_assignments on public.bug_assignments;
drop policy pmt_admin_activity_logs_insert on public.activity_logs;
drop policy pmt_admin_bug_status_history_insert on public.bug_status_history;
revoke insert,update,delete on public.build_assignments,public.bug_assignments,public.test_sessions,public.bug_retests,public.bug_status_history,public.activity_logs from authenticated;
revoke insert,update,delete on public.build_files from authenticated;
revoke insert on public.builds from authenticated;
revoke update on public.notifications from authenticated;
grant update(is_read) on public.notifications to authenticated;
create or replace function public.pmt_guard_bug_insert() returns trigger language plpgsql set search_path='' as $$
begin
 if current_user='authenticated' then
  if new.status<>'open' or new.fixed_build_id is not null or new.closed_at is not null or new.assigned_developer_id is not null or new.reported_by is distinct from auth.uid() then raise exception 'New bugs must start open and unassigned'; end if;
 end if;
 return new;
end $$;
create trigger pmt_bug_insert_guard before insert on public.bugs for each row execute function public.pmt_guard_bug_insert();
create or replace function public.pmt_guard_build_identity() returns trigger language plpgsql set search_path='' as $$
begin
 if current_user='authenticated' and (new.storage_provider is distinct from old.storage_provider or new.storage_path is distinct from old.storage_path or new.file_state is distinct from old.file_state or new.file_removed_at is distinct from old.file_removed_at or new.file_removed_by is distinct from old.file_removed_by or new.file_size is distinct from old.file_size or new.file_checksum is distinct from old.file_checksum) then raise exception 'Use the secure file management action'; end if;
 return new;
end $$;
create trigger pmt_build_identity before update on public.builds for each row execute function public.pmt_guard_build_identity();
create policy qa_edit_own_bug on public.bugs for update to authenticated using(public.pmt_is_qa() and reported_by=auth.uid() and public.pmt_bug_member(id)) with check(public.pmt_is_qa() and reported_by=auth.uid() and public.pmt_bug_member(id));

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values
 ('apks','apks',false,50000000,array['application/vnd.android.package-archive','application/octet-stream']),
 ('qa-reports','qa-reports',false,10000000,array['application/pdf','text/plain','text/csv','application/vnd.openxmlformats-officedocument.wordprocessingml.document']) on conflict(id) do nothing;
-- APK uploads and downloads are mediated by the authenticated service; no public policy.
create policy report_upload on storage.objects for insert to authenticated with check(bucket_id='qa-reports' and split_part(name,'/',2)=auth.uid()::text and (public.pmt_is_admin() or (public.pmt_is_qa() and public.pmt_project_member(split_part(name,'/',1)::uuid))));
create policy report_read on storage.objects for select to authenticated using(bucket_id='qa-reports' and (public.pmt_is_admin() or public.pmt_project_member(split_part(name,'/',1)::uuid)));
create policy attachment_admin_delete on storage.objects for delete to authenticated using(bucket_id in ('bug-screenshots','bug-videos','qa-reports') and public.pmt_is_admin());

-- Atomic upload finalization, accessible only by the authenticated Edge Function service client.
create or replace function public.pmt_finalize_upload(p_job_id uuid,p_actor uuid) returns uuid language plpgsql security definer set search_path='' as $$
declare j public.upload_jobs%rowtype; b uuid; m jsonb;
begin
 select * into j from public.upload_jobs where id=p_job_id and user_id=p_actor for update;
 if not found then raise exception 'Upload not found'; end if;
 if j.build_id is not null then return j.build_id; end if;
 if j.state<>'verified' then raise exception 'File has not been verified'; end if;
 if not exists(select 1 from public.profiles p where p.id=p_actor and p.is_active and (p.role='admin' or (p.role='developer' and exists(select 1 from public.project_members pm join public.applications a on a.project_id=pm.project_id where a.id=j.application_id and pm.user_id=p_actor)))) then raise exception 'Upload permission revoked'; end if;
 m=j.metadata;
 insert into public.builds(application_id,version_name,version_code,file_name,file_size,storage_provider,drive_file_id,storage_path,file_checksum,release_notes,uploaded_by,previous_build_id)
 values(j.application_id,m->>'version_name',(m->>'version_code')::bigint,m->>'file_name',(m->>'file_size')::bigint,j.provider,j.drive_file_id,j.provider_path,m->>'sha256',m->>'release_notes',p_actor,nullif(m->>'previous_build_id','')::uuid) returning id into b;
 insert into public.build_files(build_id,provider,provider_file_id,original_filename,byte_size,sha256,recorded_by) values(b,j.provider,coalesce(j.drive_file_id,j.provider_path),m->>'file_name',(m->>'file_size')::bigint,m->>'sha256',p_actor);
 update public.upload_jobs set state='complete',build_id=b where id=j.id;
 return b;
end $$;
revoke all on function public.pmt_finalize_upload(uuid,uuid) from public,anon,authenticated;
grant execute on function public.pmt_finalize_upload(uuid,uuid) to service_role;

create or replace function public.pmt_prepare_file_delete(p_build uuid,p_actor uuid,p_reason text) returns jsonb language plpgsql security definer set search_path='' as $$
declare b public.builds%rowtype;
begin
 if not exists(select 1 from public.profiles where id=p_actor and role='admin' and is_active) then raise exception 'Admin required'; end if;
 if length(btrim(p_reason))<5 then raise exception 'Deletion reason required'; end if;
 select * into b from public.builds where id=p_build for update;
 if not found or b.file_state='removed' then raise exception 'File is already removed or missing'; end if;
 if exists(select 1 from (select id from public.builds where application_id=b.application_id and file_state<>'removed' order by created_at desc,id desc limit 2) newest where id=b.id) then raise exception 'Latest two APKs are protected; archive older builds only'; end if;
 if b.status in ('testing','retesting','assigned_to_qa') or exists(select 1 from public.bugs where fixed_build_id=b.id and status='ready_for_retest') then raise exception 'Active QA or retest APK is protected'; end if;
 update public.builds set file_state='deleting' where id=b.id;
 insert into public.activity_logs(actor_id,build_id,event_type,new_data) values(p_actor,b.id,'apk_deletion_approved',jsonb_build_object('reason',p_reason));
 return to_jsonb(b);
end $$;
revoke all on function public.pmt_prepare_file_delete(uuid,uuid,text) from public,anon,authenticated;
grant execute on function public.pmt_prepare_file_delete(uuid,uuid,text) to service_role;

create or replace function public.pmt_ai_reserve(p_actor uuid) returns boolean language plpgsql security definer set search_path='' as $$
declare n int;
begin
 insert into pmt_private.ai_limits(user_id,requests) values(p_actor,1)
 on conflict(user_id) do update set requests=case when pmt_private.ai_limits.window_start<now()-interval '1 hour' then 1 else pmt_private.ai_limits.requests+1 end,window_start=case when pmt_private.ai_limits.window_start<now()-interval '1 hour' then now() else pmt_private.ai_limits.window_start end returning requests into n;
 return n<=20;
end $$;
revoke all on function public.pmt_ai_reserve(uuid) from public,anon,authenticated;
grant execute on function public.pmt_ai_reserve(uuid) to service_role;

create or replace function public.pmt_comment_created_audit() returns trigger language plpgsql security definer set search_path='' as $$
declare b public.bugs%rowtype;
begin
 select * into b from public.bugs where id=new.bug_id;
 insert into public.activity_logs(actor_id,bug_id,event_type,new_data) values(new.author_id,new.bug_id,'bug_comment_added',jsonb_build_object('comment_id',new.id));
 insert into public.notifications(recipient_id,event_type,bug_id,message) select distinct uid,'bug_comment',new.bug_id,'New comment on '||b.bug_code from unnest(array[b.reported_by,b.assigned_developer_id]) uid where uid is not null and uid<>new.author_id;
 return new;
end $$;
-- Privileged trigger functions must not be public RPCs.
revoke execute on function public.pmt_profile_after_signup(),public.pmt_guard_bug_code(),public.pmt_record_creation(),public.pmt_audit_attachment_created(),public.pmt_comment_created_audit() from public,anon,authenticated;
create index qa_summaries_project_idx on public.qa_summaries(project_id,created_at desc);
create index ai_jobs_user_idx on public.ai_jobs(user_id,created_at desc);


-- additional.sql
-- Apply with upgrade.sql in the same reviewed release, before frontend publication.

alter table public.bug_attachments add column removed_at timestamptz,add column removed_by uuid references public.profiles(id);
alter table public.qa_summaries add column file_removed_at timestamptz;
create or replace function public.pmt_storage_usage() returns bigint language sql security definer set search_path='' as $$
 select coalesce(sum((metadata->>'size')::bigint),0) from storage.objects
$$;
revoke all on function public.pmt_storage_usage() from public,anon,authenticated;
grant execute on function public.pmt_storage_usage() to service_role;

create or replace function public.pmt_dashboard() returns jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_build_object(
 'projects',(select count(*) from public.projects where status<>'archived'),
 'builds',(select count(*) from public.builds),
 'awaiting_qa',(select count(*) from public.builds where status in ('uploaded','awaiting_qa','assigned_to_qa')),
 'passed',(select count(*) from public.builds where status='qa_passed'),
 'failed',(select count(*) from public.builds where status='qa_failed'),
 'bugs',(select count(*) from public.bugs),
 'open_bugs',(select count(*) from public.bugs where status not in ('closed','not_a_bug')),
 'critical',(select count(*) from public.bugs where severity='critical' and status<>'closed'),
 'pending',(select count(*) from public.bugs where status='pending'),
 'retest',(select count(*) from public.bugs where status='ready_for_retest'),
 'closed',(select count(*) from public.bugs where status='closed'))
$$;
revoke all on function public.pmt_dashboard() from public,anon;
grant execute on function public.pmt_dashboard() to authenticated;

create or replace function public.pmt_retest_and_transition(p_bug_id uuid,p_outcome text,p_notes text) returns uuid language plpgsql security definer set search_path='' as $$
declare b public.bugs%rowtype; t uuid;
begin
 if nullif(btrim(coalesce(p_notes,'')),'') is null then raise exception 'Retest notes required'; end if;
 select * into b from public.bugs where id=p_bug_id for update;
 if not found then raise exception 'Bug not found'; end if;
 t:=public.pmt_submit_retest(p_bug_id,b.fixed_build_id,p_outcome,p_notes);
 if p_outcome<>'blocked' then perform public.pmt_change_bug_status(p_bug_id,case when p_outcome='passed' then 'closed' else 'reopened' end,p_notes,null); end if;
 return t;
end $$;
revoke all on function public.pmt_retest_and_transition(uuid,text,text) from public,anon;
grant execute on function public.pmt_retest_and_transition(uuid,text,text) to authenticated;

-- Prevent changing a reporter/uploader to forge history.
create or replace function public.pmt_guard_authorship() returns trigger language plpgsql set search_path='' as $$
begin
 if tg_table_name='bugs' and new.reported_by is distinct from old.reported_by then raise exception 'Reporter identity is immutable'; end if;
 return new;
end $$;
create trigger pmt_bug_authorship before update on public.bugs for each row execute function public.pmt_guard_authorship();
-- File deletion is mediated by the service. Metadata/history cannot be erased through the browser.
revoke delete on public.bug_attachments from authenticated;
create or replace function public.pmt_audit_update() returns trigger language plpgsql security definer set search_path='' as $$
begin
 insert into public.activity_logs(actor_id,project_id,build_id,bug_id,event_type,old_data,new_data)
 values(auth.uid(),case when tg_table_name='projects' then new.id else null end,case when tg_table_name='builds' then new.id else null end,case when tg_table_name='bugs' then new.id else null end,tg_table_name||'_updated',to_jsonb(old),to_jsonb(new));
 return new;
end $$;
revoke all on function public.pmt_audit_update() from public,anon,authenticated;
create trigger pmt_projects_audit_update after update on public.projects for each row execute function public.pmt_audit_update();
create trigger pmt_builds_audit_update after update on public.builds for each row execute function public.pmt_audit_update();
create trigger pmt_bugs_audit_update after update on public.bugs for each row execute function public.pmt_audit_update();
create trigger pmt_applications_audit_update after update on public.applications for each row execute function public.pmt_audit_update();
create trigger pmt_profiles_audit_update after update on public.profiles for each row execute function public.pmt_audit_update();


-- retest-hardening.sql
-- Current-resolution-cycle retest enforcement. Apply after additional.sql.

alter table public.bugs add column resolution_cycle uuid not null default gen_random_uuid();
alter table public.bug_retests add column resolution_cycle uuid;
CREATE OR REPLACE FUNCTION public.pmt_change_bug_status(p_bug_id uuid, p_status text, p_reason text DEFAULT NULL::text, p_fixed_build_id uuid DEFAULT NULL::uuid)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare b public.bugs%rowtype; admin boolean; qa boolean; dev boolean; v_next_qa uuid;
begin
 if auth.uid() is null then raise exception 'Login required' using errcode='42501'; end if;
 select * into b from public.bugs where id=p_bug_id for update;
 if not found then raise exception 'Bug not found'; end if;
 admin:=public.pmt_is_admin();qa:=public.pmt_is_qa();dev:=public.pmt_is_dev();
 if p_status not in ('in_progress','pending','not_a_bug','ready_for_retest','reopened','closed')
 then raise exception 'Invalid status transition target'; end if;
 if b.status='closed' then raise exception 'Closed bug cannot be modified without authorized reopen procedure'; end if;
 if not (
  (p_status in ('in_progress','pending','not_a_bug','ready_for_retest') and (admin or (dev and b.assigned_developer_id=auth.uid() and public.pmt_app_member(b.application_id))))
  or (p_status in ('reopened','closed') and (admin or (qa and public.pmt_app_member(b.application_id))))
 ) then raise exception 'Not authorized for this status' using errcode='42501'; end if;
 if p_status in ('in_progress','pending','not_a_bug','ready_for_retest') and b.status not in ('open','reopened','in_progress','pending','not_a_bug') then raise exception 'Bug must first be reopened or assigned'; end if;
 if p_status in ('pending','not_a_bug','ready_for_retest') and nullif(trim(coalesce(p_reason,'')),'') is null then raise exception 'Reason or resolution notes required'; end if;
 if p_status='ready_for_retest' then
  if p_fixed_build_id is null or not exists(select 1 from public.builds f where f.id=p_fixed_build_id and f.application_id=b.application_id and f.id<>b.affected_build_id and f.file_state='available') then
  raise exception 'Valid fixed build from the same application required'; end if;
 end if;
 if p_status in ('closed','reopened') then
  if b.status<>'ready_for_retest' then raise exception 'Bug must be ready for retest'; end if;
  if not exists(select 1 from public.bug_retests t where t.bug_id=b.id and t.build_id=b.fixed_build_id and t.resolution_cycle=b.resolution_cycle and t.id=(select latest.id from public.bug_retests latest where latest.bug_id=b.id and latest.resolution_cycle=b.resolution_cycle order by latest.retested_at desc,latest.id desc limit 1) and
    t.outcome=case when p_status='closed' then 'passed' else 'failed' end)
  then raise exception 'Matching QA retest result required'; end if;
 end if;
 update public.bugs set status=p_status,
 pending_reason=case when p_status in ('pending','not_a_bug') then p_reason else pending_reason end,
 resolution_notes=case when p_status='ready_for_retest' then p_reason else resolution_notes end,
 resolution_cycle=case when p_status='ready_for_retest' then gen_random_uuid() else resolution_cycle end,
 fixed_build_id=case when p_status='ready_for_retest' then p_fixed_build_id else fixed_build_id end,
 closed_at=case when p_status='closed' then now() else closed_at end,
 updated_at=now() where id=p_bug_id;
 insert into public.bug_status_history(bug_id,changed_by,from_status,to_status,reason) values(p_bug_id,auth.uid(),b.status,p_status,p_reason);
 insert into public.activity_logs(actor_id,bug_id,event_type,old_data,new_data) values(auth.uid(),p_bug_id,'bug_status_changed',jsonb_build_object('status',b.status),jsonb_build_object('status',p_status,'fixed_build_id',p_fixed_build_id));
 if p_status='ready_for_retest' then
   select ba.qa_user_id into v_next_qa from public.build_assignments ba where ba.build_id=p_fixed_build_id and ba.revoked_at is null order by ba.assigned_at desc limit 1;
   if v_next_qa is not null then insert into public.notifications(recipient_id,event_type,bug_id,build_id,message) values(v_next_qa,'bug_ready_for_retest',p_bug_id,p_fixed_build_id,'Bug is ready for QA retesting'); end if;
 elsif p_status in ('reopened','closed') and b.assigned_developer_id is not null then
   insert into public.notifications(recipient_id,event_type,bug_id,message) values(b.assigned_developer_id,'bug_'||p_status,p_bug_id,'Bug marked '||p_status);
 end if;
 return p_status;
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_submit_retest(p_bug_id uuid, p_build_id uuid, p_outcome text, p_notes text DEFAULT NULL::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare b public.bugs%rowtype; v_id uuid;
begin
 if auth.uid() is null or not (public.pmt_is_qa() or public.pmt_is_admin()) then raise exception 'QA/Admin required' using errcode='42501'; end if;
 select * into b from public.bugs where id=p_bug_id for update;
 if not found or b.status<>'ready_for_retest' or b.fixed_build_id is distinct from p_build_id then raise exception 'Bug not awaiting this build retest'; end if;
 if p_outcome not in ('passed','failed','blocked') then raise exception 'Invalid retest result'; end if;
 if not public.pmt_is_admin() and (not public.pmt_app_member(b.application_id) or not exists(
  select 1 from public.build_assignments ba where ba.build_id=p_build_id and ba.qa_user_id=auth.uid() and ba.revoked_at is null))
 then raise exception 'QA is not assigned to fixed build' using errcode='42501'; end if;
 insert into public.bug_retests(bug_id,build_id,qa_user_id,outcome,notes,resolution_cycle) values(p_bug_id,p_build_id,auth.uid(),p_outcome,p_notes,b.resolution_cycle) returning id into v_id;
 insert into public.activity_logs(actor_id,bug_id,build_id,event_type,new_data) values(auth.uid(),p_bug_id,p_build_id,'bug_retested',jsonb_build_object('outcome',p_outcome,'notes',p_notes));
 return v_id;
end $function$
;


-- archive.sql
-- Reviewed release: after retest-hardening.sql.

alter table public.builds add column archived_previous_status text;
alter table public.projects add column archived_previous_status text;
alter table public.applications add column archived_at timestamptz;
alter table public.bugs add column archived_at timestamptz;
alter table public.qa_summaries add column archived_at timestamptz;
revoke update on public.bugs from authenticated;
grant update(title,description,device_model,android_version,steps_to_reproduce,actual_result,expected_result,qa_notes,severity,priority,original_report) on public.bugs to authenticated;


-- reference-validation.sql
-- Append-only summary version consistency and private evidence references.

create or replace function public.pmt_validate_summary_reference() returns trigger language plpgsql set search_path='' as $$
begin
 if new.supersedes_id is not null and not exists(select 1 from public.qa_summaries where id=new.supersedes_id and project_id=new.project_id) then raise exception 'Previous summary must belong to the same project'; end if;
 if new.storage_path is not null and (split_part(new.storage_path,'/',1)<>new.project_id::text or split_part(new.storage_path,'/',2)<>new.author_id::text) then raise exception 'Invalid private report file reference'; end if;
 return new;
end $$;
create trigger pmt_summary_reference before insert on public.qa_summaries for each row execute function public.pmt_validate_summary_reference();
create or replace function public.pmt_validate_evidence_reference() returns trigger language plpgsql set search_path='' as $$
begin
 if split_part(new.storage_path,'/',1)<>new.bug_id::text or split_part(new.storage_path,'/',2)<>new.uploaded_by::text then raise exception 'Invalid evidence file reference'; end if;
 return new;
end $$;
create trigger pmt_evidence_reference before insert on public.bug_attachments for each row execute function public.pmt_validate_evidence_reference();


-- chat.sql
-- Chat module: append to reviewed release; not applied to the live database.

-- Public sign-up must not enroll an unknown account into company conversations.
alter table public.profiles add column chat_enabled boolean not null default false;
update public.profiles set chat_enabled=true where role='admin' and is_active;
create table public.chat_channels (
 id uuid primary key default gen_random_uuid(),
 kind text not null check(kind in ('team','project','direct')),
 project_id uuid references public.projects(id),
 user_a uuid references public.profiles(id),user_b uuid references public.profiles(id),
 created_at timestamptz not null default now(),
 constraint chat_channel_shape check(
  (kind='team' and project_id is null and user_a is null and user_b is null) or
  (kind='project' and project_id is not null and user_a is null and user_b is null) or
  (kind='direct' and project_id is null and user_a is not null and user_b is not null and user_a<user_b))
);
create unique index chat_one_team on public.chat_channels(kind) where kind='team';
create unique index chat_one_project on public.chat_channels(project_id) where kind='project';
create unique index chat_one_pair on public.chat_channels(user_a,user_b) where kind='direct';
create table public.chat_messages (
 id uuid primary key default gen_random_uuid(),seq bigint generated always as identity unique,
 channel_id uuid not null references public.chat_channels(id),sender_id uuid not null references public.profiles(id),
 client_nonce uuid not null,body text not null check(length(btrim(body)) between 1 and 4000),
 created_at timestamptz not null default clock_timestamp(),unique(sender_id,client_nonce)
);
create index chat_message_history on public.chat_messages(channel_id,seq desc);
alter table public.chat_channels enable row level security;
alter table public.chat_messages enable row level security;
revoke all on public.chat_channels,public.chat_messages from anon,authenticated;
grant select on public.chat_channels,public.chat_messages to authenticated;
grant insert(channel_id,sender_id,client_nonce,body) on public.chat_messages to authenticated;
grant usage on sequence public.chat_messages_seq_seq to authenticated;
grant all on public.chat_channels,public.chat_messages to service_role;

-- Private helper avoids recursive channel policies, but validates the live profile on every call.
create or replace function pmt_private.chat_allowed(p_channel uuid) returns boolean
language sql stable security definer set search_path='' as $$
 select auth.uid() is not null and exists(
  select 1 from public.profiles me join public.chat_channels c on c.id=p_channel
  where me.id=auth.uid() and me.is_active and (me.chat_enabled or me.role='admin') and (
   c.kind='team' or
   (c.kind='project' and (me.role='admin' or exists(select 1 from public.project_members pm where pm.project_id=c.project_id and pm.user_id=me.id))) or
   (c.kind='direct' and me.id in(c.user_a,c.user_b) and exists(select 1 from public.profiles other where other.id=case when me.id=c.user_a then c.user_b else c.user_a end and other.is_active and (other.chat_enabled or other.role='admin')))
  )
 )
$$;
revoke all on function pmt_private.chat_allowed(uuid) from public,anon;
grant usage on schema pmt_private to authenticated;
grant execute on function pmt_private.chat_allowed(uuid) to authenticated;
create policy chat_channel_read on public.chat_channels for select to authenticated using(pmt_private.chat_allowed(id));
create policy chat_message_read on public.chat_messages for select to authenticated using(pmt_private.chat_allowed(channel_id));
create policy chat_message_send on public.chat_messages for insert to authenticated
 with check(sender_id=(select auth.uid()) and pmt_private.chat_allowed(channel_id));

-- The directory deliberately exposes only active colleague name/role/ID, not email or private assignments.
create or replace function pmt_private.chat_directory() returns table(id uuid,full_name text,role text)
language sql stable security definer set search_path='' as $$
 select p.id,coalesce(nullif(p.full_name,''),'Team member'),p.role from public.profiles p
 where p.is_active and (p.chat_enabled or p.role='admin') and auth.uid() is not null and exists(select 1 from public.profiles me where me.id=auth.uid() and me.is_active and (me.chat_enabled or me.role='admin'))
 order by p.full_name,p.id
$$;
revoke all on function pmt_private.chat_directory() from public,anon;
grant execute on function pmt_private.chat_directory() to authenticated;
create or replace function public.pmt_chat_directory() returns table(id uuid,full_name text,role text)
language sql stable security invoker set search_path='' as $$select * from pmt_private.chat_directory()$$;
revoke all on function public.pmt_chat_directory() from public,anon;
grant execute on function public.pmt_chat_directory() to authenticated;

create or replace function pmt_private.open_direct_chat(p_other uuid) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_id uuid; a uuid; b uuid;
begin
 if auth.uid() is null or p_other=auth.uid() or not exists(select 1 from public.profiles where id=auth.uid() and is_active and (chat_enabled or role='admin')) or not exists(select 1 from public.profiles where id=p_other and is_active and (chat_enabled or role='admin')) then raise exception 'Approved active colleague access required' using errcode='42501'; end if;
 a:=least(auth.uid(),p_other);b:=greatest(auth.uid(),p_other);
 insert into public.chat_channels(kind,user_a,user_b) values('direct',a,b)
 on conflict(user_a,user_b) where kind='direct' do nothing;
 select id into v_id from public.chat_channels where kind='direct' and user_a=a and user_b=b;
 return v_id;
end $$;
revoke all on function pmt_private.open_direct_chat(uuid) from public,anon;
grant execute on function pmt_private.open_direct_chat(uuid) to authenticated;
create or replace function public.pmt_open_direct_chat(p_other uuid) returns uuid
language sql security invoker set search_path='' as $$select pmt_private.open_direct_chat(p_other)$$;
revoke all on function public.pmt_open_direct_chat(uuid) from public,anon;
grant execute on function public.pmt_open_direct_chat(uuid) to authenticated;

-- Every project gets exactly one channel; its current membership controls historical access too.
insert into public.chat_channels(kind) values('team');
insert into public.chat_channels(kind,project_id) select 'project',id from public.projects;
create or replace function pmt_private.chat_project_created() returns trigger
language plpgsql security definer set search_path='' as $$
begin insert into public.chat_channels(kind,project_id) values('project',new.id);return new;end $$;
revoke all on function pmt_private.chat_project_created() from public,anon,authenticated;
create trigger pmt_project_chat after insert on public.projects for each row execute function pmt_private.chat_project_created();


-- access-hardening.sql
-- Revoked-project and inactive-account hardening; tested locally only.

CREATE OR REPLACE FUNCTION public.pmt_review_not_a_bug(p_bug_id uuid, p_accept boolean, p_reason text)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare b public.bugs%rowtype;
begin
 if auth.uid() is null or not (public.pmt_is_admin() or
  (public.pmt_is_qa() and exists(select 1 from public.bugs x where x.id=p_bug_id and x.reported_by=auth.uid() and public.pmt_app_member(x.application_id))))
 then raise exception 'QA reporter or Admin authorization required' using errcode='42501'; end if;
 if nullif(btrim(coalesce(p_reason,'')),'') is null then raise exception 'Review reason required'; end if;
 select * into b from public.bugs where id=p_bug_id for update;
 if not found or b.status<>'not_a_bug' then raise exception 'Bug is not awaiting Not a Bug review'; end if;
 if p_accept then
  insert into public.activity_logs(actor_id,bug_id,event_type,new_data)
  values(auth.uid(),p_bug_id,'not_a_bug_accepted',jsonb_build_object('reason',p_reason));
  return 'not_a_bug';
 end if;
 update public.bugs set status='reopened',updated_at=now() where id=p_bug_id;
 insert into public.bug_status_history(bug_id,changed_by,from_status,to_status,reason)
 values(p_bug_id,auth.uid(),'not_a_bug','reopened',p_reason);
 insert into public.activity_logs(actor_id,bug_id,event_type,new_data)
 values(auth.uid(),p_bug_id,'not_a_bug_rejected',jsonb_build_object('reason',p_reason));
 if b.assigned_developer_id is not null then
  insert into public.notifications(recipient_id,event_type,bug_id,message)
  values(b.assigned_developer_id,'bug_reopened',p_bug_id,'QA/Admin rejected Not a Bug decision');
 end if;
 return 'reopened';
end $function$;
drop policy pmt_read_notifications on public.notifications;
create policy pmt_read_notifications on public.notifications for select to authenticated using((public.pmt_is_admin() or recipient_id=auth.uid()) and (public.pmt_is_admin() or public.pmt_is_qa() or public.pmt_is_dev()));
drop policy pmt_user_notification_readmark on public.notifications;
create policy pmt_user_notification_readmark on public.notifications for update to authenticated using(recipient_id=auth.uid() and (public.pmt_is_admin() or public.pmt_is_qa() or public.pmt_is_dev())) with check(recipient_id=auth.uid() and (public.pmt_is_admin() or public.pmt_is_qa() or public.pmt_is_dev()));

commit;
