-- Apply with upgrade.sql in the same reviewed release, before frontend publication.
begin;
alter table public.bug_attachments add column removed_at timestamptz,add column removed_by uuid references public.profiles(id);
alter table public.qa_summaries add column file_removed_at timestamptz;
create or replace function public.pmt_storage_usage() returns bigint language sql security definer set search_path='' as $$
 select coalesce(sum((metadata->>'size')::bigint),0) from storage.objects
$$;
revoke all on function public.pmt_storage_usage() from public,anon,authenticated;
grant execute on function public.pmt_storage_usage() to service_role;

create or replace function public.pmt_dashboard() returns jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_build_object(
 'projects',(select count(*) from public.projects where status<>'archived'),
 'builds',(select count(*) from public.builds),
 'awaiting_qa',(select count(*) from public.builds where status in ('uploaded','awaiting_qa','assigned_to_qa')),
 'passed',(select count(*) from public.builds where status='qa_passed'),
 'failed',(select count(*) from public.builds where status='qa_failed'),
 'bugs',(select count(*) from public.bugs),
 'open_bugs',(select count(*) from public.bugs where status not in ('closed','not_a_bug')),
 'critical',(select count(*) from public.bugs where severity='critical' and status<>'closed'),
 'pending',(select count(*) from public.bugs where status='pending'),
 'retest',(select count(*) from public.bugs where status='ready_for_retest'),
 'closed',(select count(*) from public.bugs where status='closed'))
$$;
revoke all on function public.pmt_dashboard() from public,anon;
grant execute on function public.pmt_dashboard() to authenticated;

create or replace function public.pmt_retest_and_transition(p_bug_id uuid,p_outcome text,p_notes text) returns uuid language plpgsql security definer set search_path='' as $$
declare b public.bugs%rowtype; t uuid;
begin
 if nullif(btrim(coalesce(p_notes,'')),'') is null then raise exception 'Retest notes required'; end if;
 select * into b from public.bugs where id=p_bug_id for update;
 if not found then raise exception 'Bug not found'; end if;
 t:=public.pmt_submit_retest(p_bug_id,b.fixed_build_id,p_outcome,p_notes);
 if p_outcome<>'blocked' then perform public.pmt_change_bug_status(p_bug_id,case when p_outcome='passed' then 'closed' else 'reopened' end,p_notes,null); end if;
 return t;
end $$;
revoke all on function public.pmt_retest_and_transition(uuid,text,text) from public,anon;
grant execute on function public.pmt_retest_and_transition(uuid,text,text) to authenticated;

-- Prevent changing a reporter/uploader to forge history.
create or replace function public.pmt_guard_authorship() returns trigger language plpgsql set search_path='' as $$
begin
 if tg_table_name='bugs' and new.reported_by is distinct from old.reported_by then raise exception 'Reporter identity is immutable'; end if;
 return new;
end $$;
create trigger pmt_bug_authorship before update on public.bugs for each row execute function public.pmt_guard_authorship();
-- File deletion is mediated by the service. Metadata/history cannot be erased through the browser.
revoke delete on public.bug_attachments from authenticated;
create or replace function public.pmt_audit_update() returns trigger language plpgsql security definer set search_path='' as $$
begin
 insert into public.activity_logs(actor_id,project_id,build_id,bug_id,event_type,old_data,new_data)
 values(auth.uid(),case when tg_table_name='projects' then new.id else null end,case when tg_table_name='builds' then new.id else null end,case when tg_table_name='bugs' then new.id else null end,tg_table_name||'_updated',to_jsonb(old),to_jsonb(new));
 return new;
end $$;
revoke all on function public.pmt_audit_update() from public,anon,authenticated;
create trigger pmt_projects_audit_update after update on public.projects for each row execute function public.pmt_audit_update();
create trigger pmt_builds_audit_update after update on public.builds for each row execute function public.pmt_audit_update();
create trigger pmt_bugs_audit_update after update on public.bugs for each row execute function public.pmt_audit_update();
create trigger pmt_applications_audit_update after update on public.applications for each row execute function public.pmt_audit_update();
create trigger pmt_profiles_audit_update after update on public.profiles for each row execute function public.pmt_audit_update();
commit;
