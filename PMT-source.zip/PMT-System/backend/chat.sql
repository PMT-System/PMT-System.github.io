-- Chat module: append to reviewed release; not applied to the live database.
begin;
-- Public sign-up must not enroll an unknown account into company conversations.
alter table public.profiles add column chat_enabled boolean not null default false;
update public.profiles set chat_enabled=true where role='admin' and is_active;
create table public.chat_channels (
 id uuid primary key default gen_random_uuid(),
 kind text not null check(kind in ('team','project','direct')),
 project_id uuid references public.projects(id),
 user_a uuid references public.profiles(id),user_b uuid references public.profiles(id),
 created_at timestamptz not null default now(),
 constraint chat_channel_shape check(
  (kind='team' and project_id is null and user_a is null and user_b is null) or
  (kind='project' and project_id is not null and user_a is null and user_b is null) or
  (kind='direct' and project_id is null and user_a is not null and user_b is not null and user_a<user_b))
);
create unique index chat_one_team on public.chat_channels(kind) where kind='team';
create unique index chat_one_project on public.chat_channels(project_id) where kind='project';
create unique index chat_one_pair on public.chat_channels(user_a,user_b) where kind='direct';
create table public.chat_messages (
 id uuid primary key default gen_random_uuid(),seq bigint generated always as identity unique,
 channel_id uuid not null references public.chat_channels(id),sender_id uuid not null references public.profiles(id),
 client_nonce uuid not null,body text not null check(length(btrim(body)) between 1 and 4000),
 created_at timestamptz not null default clock_timestamp(),unique(sender_id,client_nonce)
);
create index chat_message_history on public.chat_messages(channel_id,seq desc);
alter table public.chat_channels enable row level security;
alter table public.chat_messages enable row level security;
revoke all on public.chat_channels,public.chat_messages from anon,authenticated;
grant select on public.chat_channels,public.chat_messages to authenticated;
grant insert(channel_id,sender_id,client_nonce,body) on public.chat_messages to authenticated;
grant usage on sequence public.chat_messages_seq_seq to authenticated;
grant all on public.chat_channels,public.chat_messages to service_role;

-- Private helper avoids recursive channel policies, but validates the live profile on every call.
create or replace function pmt_private.chat_allowed(p_channel uuid) returns boolean
language sql stable security definer set search_path='' as $$
 select auth.uid() is not null and exists(
  select 1 from public.profiles me join public.chat_channels c on c.id=p_channel
  where me.id=auth.uid() and me.is_active and (me.chat_enabled or me.role='admin') and (
   c.kind='team' or
   (c.kind='project' and (me.role='admin' or exists(select 1 from public.project_members pm where pm.project_id=c.project_id and pm.user_id=me.id))) or
   (c.kind='direct' and me.id in(c.user_a,c.user_b) and exists(select 1 from public.profiles other where other.id=case when me.id=c.user_a then c.user_b else c.user_a end and other.is_active and (other.chat_enabled or other.role='admin')))
  )
 )
$$;
revoke all on function pmt_private.chat_allowed(uuid) from public,anon;
grant usage on schema pmt_private to authenticated;
grant execute on function pmt_private.chat_allowed(uuid) to authenticated;
create policy chat_channel_read on public.chat_channels for select to authenticated using(pmt_private.chat_allowed(id));
create policy chat_message_read on public.chat_messages for select to authenticated using(pmt_private.chat_allowed(channel_id));
create policy chat_message_send on public.chat_messages for insert to authenticated
 with check(sender_id=(select auth.uid()) and pmt_private.chat_allowed(channel_id));

-- The directory deliberately exposes only active colleague name/role/ID, not email or private assignments.
create or replace function pmt_private.chat_directory() returns table(id uuid,full_name text,role text)
language sql stable security definer set search_path='' as $$
 select p.id,coalesce(nullif(p.full_name,''),'Team member'),p.role from public.profiles p
 where p.is_active and (p.chat_enabled or p.role='admin') and auth.uid() is not null and exists(select 1 from public.profiles me where me.id=auth.uid() and me.is_active and (me.chat_enabled or me.role='admin'))
 order by p.full_name,p.id
$$;
revoke all on function pmt_private.chat_directory() from public,anon;
grant execute on function pmt_private.chat_directory() to authenticated;
create or replace function public.pmt_chat_directory() returns table(id uuid,full_name text,role text)
language sql stable security invoker set search_path='' as $$select * from pmt_private.chat_directory()$$;
revoke all on function public.pmt_chat_directory() from public,anon;
grant execute on function public.pmt_chat_directory() to authenticated;

create or replace function pmt_private.open_direct_chat(p_other uuid) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_id uuid; a uuid; b uuid;
begin
 if auth.uid() is null or p_other=auth.uid() or not exists(select 1 from public.profiles where id=auth.uid() and is_active and (chat_enabled or role='admin')) or not exists(select 1 from public.profiles where id=p_other and is_active and (chat_enabled or role='admin')) then raise exception 'Approved active colleague access required' using errcode='42501'; end if;
 a:=least(auth.uid(),p_other);b:=greatest(auth.uid(),p_other);
 insert into public.chat_channels(kind,user_a,user_b) values('direct',a,b)
 on conflict(user_a,user_b) where kind='direct' do nothing;
 select id into v_id from public.chat_channels where kind='direct' and user_a=a and user_b=b;
 return v_id;
end $$;
revoke all on function pmt_private.open_direct_chat(uuid) from public,anon;
grant execute on function pmt_private.open_direct_chat(uuid) to authenticated;
create or replace function public.pmt_open_direct_chat(p_other uuid) returns uuid
language sql security invoker set search_path='' as $$select pmt_private.open_direct_chat(p_other)$$;
revoke all on function public.pmt_open_direct_chat(uuid) from public,anon;
grant execute on function public.pmt_open_direct_chat(uuid) to authenticated;

-- Every project gets exactly one channel; its current membership controls historical access too.
insert into public.chat_channels(kind) values('team');
insert into public.chat_channels(kind,project_id) select 'project',id from public.projects;
create or replace function pmt_private.chat_project_created() returns trigger
language plpgsql security definer set search_path='' as $$
begin insert into public.chat_channels(kind,project_id) values('project',new.id);return new;end $$;
revoke all on function pmt_private.chat_project_created() from public,anon,authenticated;
create trigger pmt_project_chat after insert on public.projects for each row execute function pmt_private.chat_project_created();
commit;
