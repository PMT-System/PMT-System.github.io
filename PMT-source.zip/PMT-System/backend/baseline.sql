-- Schema-only snapshot of existing Supabase project, 16 October 2026.
-- FOR AN EMPTY SUPABASE DATABASE ONLY. Do not run on the existing project.
-- No user records, passwords, tokens or file objects included.
begin;
set local check_function_bodies=off;
CREATE SEQUENCE public.pmt_bug_seq;
CREATE TABLE public.activity_logs (
id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
actor_id uuid,
project_id uuid,
build_id uuid,
bug_id uuid,
event_type text NOT NULL,
old_data jsonb,
new_data jsonb,
occurred_at timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE public.app_settings (
key text NOT NULL,
value jsonb NOT NULL,
updated_by uuid,
updated_at timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE public.applications (
id uuid DEFAULT gen_random_uuid() NOT NULL,
project_id uuid NOT NULL,
app_name text NOT NULL,
package_name text NOT NULL,
description text,
created_at timestamp with time zone DEFAULT now(),
updated_at timestamp with time zone DEFAULT now()
);
CREATE TABLE public.bug_assignments (
id uuid DEFAULT gen_random_uuid() NOT NULL,
bug_id uuid NOT NULL,
developer_id uuid NOT NULL,
assigned_by uuid NOT NULL,
assigned_at timestamp with time zone DEFAULT now() NOT NULL,
unassigned_at timestamp with time zone
);
CREATE TABLE public.bug_attachments (
id uuid DEFAULT gen_random_uuid() NOT NULL,
bug_id uuid NOT NULL,
uploaded_by uuid NOT NULL,
bucket_name text NOT NULL,
storage_path text NOT NULL,
file_name text NOT NULL,
mime_type text NOT NULL,
file_size bigint NOT NULL,
created_at timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE public.bug_comments (
id uuid DEFAULT gen_random_uuid() NOT NULL,
bug_id uuid NOT NULL,
author_id uuid NOT NULL,
body text NOT NULL,
created_at timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE public.bug_retests (
id uuid DEFAULT gen_random_uuid() NOT NULL,
bug_id uuid NOT NULL,
build_id uuid NOT NULL,
qa_user_id uuid NOT NULL,
outcome text NOT NULL,
notes text,
retested_at timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE public.bug_status_history (
id uuid DEFAULT gen_random_uuid() NOT NULL,
bug_id uuid NOT NULL,
changed_by uuid NOT NULL,
from_status text,
to_status text NOT NULL,
reason text,
changed_at timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE public.bugs (
id uuid DEFAULT gen_random_uuid() NOT NULL,
bug_code text NOT NULL,
application_id uuid NOT NULL,
affected_build_id uuid NOT NULL,
title text NOT NULL,
description text,
device_model text,
android_version text,
steps_to_reproduce text,
actual_result text,
expected_result text,
qa_notes text,
severity text DEFAULT 'minor'::text NOT NULL,
priority text DEFAULT 'medium'::text NOT NULL,
status text DEFAULT 'open'::text NOT NULL,
assigned_developer_id uuid,
reported_by uuid NOT NULL,
pending_reason text,
resolution_notes text,
fixed_build_id uuid,
closed_at timestamp with time zone,
created_at timestamp with time zone DEFAULT now() NOT NULL,
updated_at timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE public.build_assignments (
id uuid DEFAULT gen_random_uuid() NOT NULL,
build_id uuid NOT NULL,
qa_user_id uuid NOT NULL,
assigned_by uuid,
assigned_at timestamp with time zone DEFAULT now() NOT NULL,
revoked_at timestamp with time zone
);
CREATE TABLE public.build_files (
id uuid DEFAULT gen_random_uuid() NOT NULL,
build_id uuid NOT NULL,
provider text DEFAULT 'google_drive'::text NOT NULL,
provider_file_id text NOT NULL,
original_filename text NOT NULL,
byte_size bigint NOT NULL,
sha256 text,
recorded_by uuid NOT NULL,
created_at timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE public.builds (
id uuid DEFAULT gen_random_uuid() NOT NULL,
application_id uuid NOT NULL,
version_name text NOT NULL,
version_code bigint NOT NULL,
file_name text,
file_size bigint,
storage_provider text DEFAULT 'google_drive'::text NOT NULL,
drive_file_id text,
file_checksum text,
release_notes text,
uploaded_by uuid,
previous_build_id uuid,
status text DEFAULT 'uploaded'::text NOT NULL,
created_at timestamp with time zone DEFAULT now() NOT NULL,
updated_at timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE public.notifications (
id uuid DEFAULT gen_random_uuid() NOT NULL,
recipient_id uuid NOT NULL,
event_type text NOT NULL,
project_id uuid,
build_id uuid,
bug_id uuid,
message text NOT NULL,
is_read boolean DEFAULT false NOT NULL,
created_at timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE public.profiles (
id uuid NOT NULL,
full_name text,
email text,
role text DEFAULT 'developer'::text NOT NULL,
is_active boolean DEFAULT true NOT NULL,
created_at timestamp with time zone DEFAULT now(),
updated_at timestamp with time zone DEFAULT now()
);
CREATE TABLE public.project_members (
id uuid DEFAULT gen_random_uuid() NOT NULL,
project_id uuid NOT NULL,
user_id uuid NOT NULL,
assigned_at timestamp with time zone DEFAULT now()
);
CREATE TABLE public.projects (
id uuid DEFAULT gen_random_uuid() NOT NULL,
project_name text NOT NULL,
description text,
status text DEFAULT 'active'::text NOT NULL,
notes text,
created_by uuid,
created_at timestamp with time zone DEFAULT now(),
updated_at timestamp with time zone DEFAULT now()
);
CREATE TABLE public.test_sessions (
id uuid DEFAULT gen_random_uuid() NOT NULL,
build_id uuid NOT NULL,
qa_user_id uuid NOT NULL,
result text DEFAULT 'not_started'::text NOT NULL,
notes text,
started_at timestamp with time zone,
completed_at timestamp with time zone,
created_at timestamp with time zone DEFAULT now() NOT NULL
);
ALTER TABLE public.project_members ADD CONSTRAINT project_members_pkey PRIMARY KEY (id);
ALTER TABLE public.project_members ADD CONSTRAINT project_members_project_id_user_id_key UNIQUE (project_id, user_id);
ALTER TABLE public.profiles ADD CONSTRAINT profiles_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'qa'::text, 'developer'::text])));
ALTER TABLE public.profiles ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);
ALTER TABLE public.projects ADD CONSTRAINT projects_status_check CHECK ((status = ANY (ARRAY['active'::text, 'on_hold'::text, 'completed'::text, 'archived'::text])));
ALTER TABLE public.projects ADD CONSTRAINT projects_pkey PRIMARY KEY (id);
ALTER TABLE public.applications ADD CONSTRAINT applications_pkey PRIMARY KEY (id);
ALTER TABLE public.applications ADD CONSTRAINT applications_package_name_key UNIQUE (package_name);
ALTER TABLE public.builds ADD CONSTRAINT builds_version_code_check CHECK ((version_code > 0));
ALTER TABLE public.builds ADD CONSTRAINT builds_file_size_check CHECK ((file_size >= 0));
ALTER TABLE public.builds ADD CONSTRAINT builds_storage_provider_check CHECK ((storage_provider = 'google_drive'::text));
ALTER TABLE public.builds ADD CONSTRAINT builds_status_check CHECK ((status = ANY (ARRAY['uploaded'::text, 'awaiting_qa'::text, 'assigned_to_qa'::text, 'testing'::text, 'qa_passed'::text, 'qa_failed'::text, 'fix_required'::text, 'retesting'::text, 'archived'::text])));
ALTER TABLE public.builds ADD CONSTRAINT builds_pkey PRIMARY KEY (id);
ALTER TABLE public.builds ADD CONSTRAINT builds_application_id_version_code_key UNIQUE (application_id, version_code);
ALTER TABLE public.build_assignments ADD CONSTRAINT build_assignments_pkey PRIMARY KEY (id);
ALTER TABLE public.test_sessions ADD CONSTRAINT test_sessions_result_check CHECK ((result = ANY (ARRAY['not_started'::text, 'in_progress'::text, 'passed'::text, 'failed'::text, 'blocked'::text])));
ALTER TABLE public.test_sessions ADD CONSTRAINT test_sessions_pkey PRIMARY KEY (id);
ALTER TABLE public.bugs ADD CONSTRAINT bugs_title_check CHECK ((length(TRIM(BOTH FROM title)) > 0));
ALTER TABLE public.build_files ADD CONSTRAINT build_files_byte_size_check CHECK ((byte_size > 0));
ALTER TABLE public.bugs ADD CONSTRAINT bugs_severity_check CHECK ((severity = ANY (ARRAY['critical'::text, 'major'::text, 'minor'::text, 'trivial'::text])));
ALTER TABLE public.bugs ADD CONSTRAINT bugs_priority_check CHECK ((priority = ANY (ARRAY['high'::text, 'medium'::text, 'low'::text])));
ALTER TABLE public.bugs ADD CONSTRAINT bugs_status_check CHECK ((status = ANY (ARRAY['open'::text, 'in_progress'::text, 'pending'::text, 'not_a_bug'::text, 'ready_for_retest'::text, 'reopened'::text, 'closed'::text])));
ALTER TABLE public.bugs ADD CONSTRAINT bugs_pkey PRIMARY KEY (id);
ALTER TABLE public.bugs ADD CONSTRAINT bugs_bug_code_key UNIQUE (bug_code);
ALTER TABLE public.bug_assignments ADD CONSTRAINT bug_assignments_pkey PRIMARY KEY (id);
ALTER TABLE public.bug_comments ADD CONSTRAINT bug_comments_body_check CHECK ((length(TRIM(BOTH FROM body)) > 0));
ALTER TABLE public.bug_comments ADD CONSTRAINT bug_comments_pkey PRIMARY KEY (id);
ALTER TABLE public.build_files ADD CONSTRAINT build_files_pkey PRIMARY KEY (id);
ALTER TABLE public.bug_attachments ADD CONSTRAINT bug_attachments_bucket_name_check CHECK ((bucket_name = ANY (ARRAY['bug-screenshots'::text, 'bug-videos'::text])));
ALTER TABLE public.bug_attachments ADD CONSTRAINT bug_attachments_file_size_check CHECK ((file_size >= 0));
ALTER TABLE public.bug_attachments ADD CONSTRAINT bug_attachments_pkey PRIMARY KEY (id);
ALTER TABLE public.bug_attachments ADD CONSTRAINT bug_attachments_storage_path_key UNIQUE (storage_path);
ALTER TABLE public.bug_status_history ADD CONSTRAINT bug_status_history_pkey PRIMARY KEY (id);
ALTER TABLE public.bug_retests ADD CONSTRAINT bug_retests_outcome_check CHECK ((outcome = ANY (ARRAY['passed'::text, 'failed'::text, 'blocked'::text])));
ALTER TABLE public.bug_retests ADD CONSTRAINT bug_retests_pkey PRIMARY KEY (id);
ALTER TABLE public.notifications ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);
ALTER TABLE public.activity_logs ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);
ALTER TABLE public.build_files ADD CONSTRAINT build_files_provider_check CHECK ((provider = 'google_drive'::text));
ALTER TABLE public.build_files ADD CONSTRAINT build_files_build_id_key UNIQUE (build_id);
ALTER TABLE public.build_files ADD CONSTRAINT build_files_provider_file_id_key UNIQUE (provider_file_id);
ALTER TABLE public.app_settings ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);
ALTER TABLE public.bugs ADD CONSTRAINT bugs_reported_by_fkey FOREIGN KEY (reported_by) REFERENCES profiles(id);
ALTER TABLE public.bugs ADD CONSTRAINT bugs_fixed_build_id_fkey FOREIGN KEY (fixed_build_id) REFERENCES builds(id);
ALTER TABLE public.project_members ADD CONSTRAINT project_members_project_id_fkey FOREIGN KEY (project_id) REFERENCES projects(id);
ALTER TABLE public.project_members ADD CONSTRAINT project_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES profiles(id);
ALTER TABLE public.build_files ADD CONSTRAINT build_files_recorded_by_fkey FOREIGN KEY (recorded_by) REFERENCES profiles(id);
ALTER TABLE public.bug_assignments ADD CONSTRAINT bug_assignments_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bugs(id);
ALTER TABLE public.profiles ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id);
ALTER TABLE public.bug_assignments ADD CONSTRAINT bug_assignments_developer_id_fkey FOREIGN KEY (developer_id) REFERENCES profiles(id);
ALTER TABLE public.bug_assignments ADD CONSTRAINT bug_assignments_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES profiles(id);
ALTER TABLE public.projects ADD CONSTRAINT projects_created_by_fkey FOREIGN KEY (created_by) REFERENCES profiles(id);
ALTER TABLE public.notifications ADD CONSTRAINT notifications_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES profiles(id);
ALTER TABLE public.notifications ADD CONSTRAINT notifications_project_id_fkey FOREIGN KEY (project_id) REFERENCES projects(id);
ALTER TABLE public.applications ADD CONSTRAINT applications_project_id_fkey FOREIGN KEY (project_id) REFERENCES projects(id);
ALTER TABLE public.bug_comments ADD CONSTRAINT bug_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES profiles(id);
ALTER TABLE public.bug_comments ADD CONSTRAINT bug_comments_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bugs(id);
ALTER TABLE public.notifications ADD CONSTRAINT notifications_build_id_fkey FOREIGN KEY (build_id) REFERENCES builds(id);
ALTER TABLE public.notifications ADD CONSTRAINT notifications_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bugs(id);
ALTER TABLE public.app_settings ADD CONSTRAINT app_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES profiles(id);
ALTER TABLE public.activity_logs ADD CONSTRAINT activity_logs_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES profiles(id);
ALTER TABLE public.activity_logs ADD CONSTRAINT activity_logs_project_id_fkey FOREIGN KEY (project_id) REFERENCES projects(id);
ALTER TABLE public.builds ADD CONSTRAINT builds_application_id_fkey FOREIGN KEY (application_id) REFERENCES applications(id);
ALTER TABLE public.builds ADD CONSTRAINT builds_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES profiles(id);
ALTER TABLE public.builds ADD CONSTRAINT builds_previous_build_id_fkey FOREIGN KEY (previous_build_id) REFERENCES builds(id);
ALTER TABLE public.bug_attachments ADD CONSTRAINT bug_attachments_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bugs(id);
ALTER TABLE public.build_assignments ADD CONSTRAINT build_assignments_build_id_fkey FOREIGN KEY (build_id) REFERENCES builds(id);
ALTER TABLE public.build_assignments ADD CONSTRAINT build_assignments_qa_user_id_fkey FOREIGN KEY (qa_user_id) REFERENCES profiles(id);
ALTER TABLE public.build_assignments ADD CONSTRAINT build_assignments_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES profiles(id);
ALTER TABLE public.bug_attachments ADD CONSTRAINT bug_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES profiles(id);
ALTER TABLE public.activity_logs ADD CONSTRAINT activity_logs_build_id_fkey FOREIGN KEY (build_id) REFERENCES builds(id);
ALTER TABLE public.test_sessions ADD CONSTRAINT test_sessions_build_id_fkey FOREIGN KEY (build_id) REFERENCES builds(id);
ALTER TABLE public.test_sessions ADD CONSTRAINT test_sessions_qa_user_id_fkey FOREIGN KEY (qa_user_id) REFERENCES profiles(id);
ALTER TABLE public.bug_status_history ADD CONSTRAINT bug_status_history_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bugs(id);
ALTER TABLE public.bug_status_history ADD CONSTRAINT bug_status_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES profiles(id);
ALTER TABLE public.activity_logs ADD CONSTRAINT activity_logs_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bugs(id);
ALTER TABLE public.build_files ADD CONSTRAINT build_files_build_id_fkey FOREIGN KEY (build_id) REFERENCES builds(id);
ALTER TABLE public.bug_retests ADD CONSTRAINT bug_retests_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bugs(id);
ALTER TABLE public.bug_retests ADD CONSTRAINT bug_retests_build_id_fkey FOREIGN KEY (build_id) REFERENCES builds(id);
ALTER TABLE public.bug_retests ADD CONSTRAINT bug_retests_qa_user_id_fkey FOREIGN KEY (qa_user_id) REFERENCES profiles(id);
ALTER TABLE public.bugs ADD CONSTRAINT bugs_application_id_fkey FOREIGN KEY (application_id) REFERENCES applications(id);
ALTER TABLE public.bugs ADD CONSTRAINT bugs_affected_build_id_fkey FOREIGN KEY (affected_build_id) REFERENCES builds(id);
ALTER TABLE public.bugs ADD CONSTRAINT bugs_assigned_developer_id_fkey FOREIGN KEY (assigned_developer_id) REFERENCES profiles(id);
CREATE OR REPLACE FUNCTION public.pmt_app_member(app uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$ select exists(select 1 from public.applications a where a.id=app and public.pmt_project_member(a.project_id)) $function$
;
CREATE OR REPLACE FUNCTION public.pmt_assign_bug(p_bug_id uuid, p_developer_id uuid)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare b public.bugs%rowtype; v_id uuid;
begin
 if auth.uid() is null or not public.pmt_is_admin() then raise exception 'Admin authorization required' using errcode='42501'; end if;
 select * into b from public.bugs where id=p_bug_id for update;
 if not found then raise exception 'Bug not found'; end if;
 if not exists(select 1 from public.profiles p join public.project_members pm on pm.user_id=p.id join public.applications a on a.project_id=pm.project_id where p.id=p_developer_id and p.role='developer' and p.is_active and a.id=b.application_id)
 then raise exception 'Developer must be an active member of this project'; end if;
 update public.bug_assignments set unassigned_at=now() where bug_id=p_bug_id and unassigned_at is null;
 insert into public.bug_assignments(bug_id,developer_id,assigned_by) values(p_bug_id,p_developer_id,auth.uid()) returning id into v_id;
 update public.bugs set assigned_developer_id=p_developer_id,updated_at=now() where id=p_bug_id;
 insert into public.notifications(recipient_id,event_type,bug_id,message) values(p_developer_id,'bug_assigned',p_bug_id,'A bug was assigned to you');
 insert into public.activity_logs(actor_id,bug_id,event_type,new_data) values(auth.uid(),p_bug_id,'bug_assigned',jsonb_build_object('developer_id',p_developer_id));
 return v_id;
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_assign_build(p_build_id uuid, p_qa_id uuid)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare b public.builds%rowtype; v_id uuid;
begin
 if auth.uid() is null or not public.pmt_is_admin() then raise exception 'Admin authorization required' using errcode='42501'; end if;
 select * into b from public.builds where id=p_build_id for update;
 if not found then raise exception 'Build not found'; end if;
 if not exists(select 1 from public.profiles p join public.project_members pm on pm.user_id=p.id join public.applications a on a.project_id=pm.project_id
 where p.id=p_qa_id and p.role='qa' and p.is_active and a.id=b.application_id) then raise exception 'QA user must be an active project member'; end if;
 update public.build_assignments set revoked_at=now() where build_id=p_build_id and revoked_at is null;
 insert into public.build_assignments(build_id,qa_user_id,assigned_by) values(p_build_id,p_qa_id,auth.uid()) returning id into v_id;
 update public.builds set status='assigned_to_qa',updated_at=now() where id=p_build_id;
 insert into public.notifications(recipient_id,event_type,build_id,message) values(p_qa_id,'build_assigned',p_build_id,'A build was assigned to you');
 insert into public.activity_logs(actor_id,build_id,event_type,new_data) values(auth.uid(),p_build_id,'build_assigned',jsonb_build_object('qa_user_id',p_qa_id));
 return v_id;
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_audit_attachment_created()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
begin
 insert into public.activity_logs(actor_id,bug_id,event_type,new_data)
 values(new.uploaded_by,new.bug_id,'bug_attachment_uploaded',
 jsonb_build_object('attachment_id',new.id,'bucket',new.bucket_name,'bytes',new.file_size));
 return new;
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_bug_member(bug uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$ select exists(select 1 from public.bugs b where b.id=bug and public.pmt_app_member(b.application_id)) $function$
;
CREATE OR REPLACE FUNCTION public.pmt_build_member(build uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$ select exists(select 1 from public.builds b where b.id=build and public.pmt_app_member(b.application_id)) $function$
;
CREATE OR REPLACE FUNCTION public.pmt_change_bug_status(p_bug_id uuid, p_status text, p_reason text DEFAULT NULL::text, p_fixed_build_id uuid DEFAULT NULL::uuid)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare b public.bugs%rowtype; admin boolean; qa boolean; dev boolean; v_next_qa uuid;
begin
 if auth.uid() is null then raise exception 'Login required' using errcode='42501'; end if;
 select * into b from public.bugs where id=p_bug_id for update;
 if not found then raise exception 'Bug not found'; end if;
 admin:=public.pmt_is_admin();qa:=public.pmt_is_qa();dev:=public.pmt_is_dev();
 if p_status not in ('in_progress','pending','not_a_bug','ready_for_retest','reopened','closed')
 then raise exception 'Invalid status transition target'; end if;
 if b.status='closed' then raise exception 'Closed bug cannot be modified without authorized reopen procedure'; end if;
 if not (
  (p_status in ('in_progress','pending','not_a_bug','ready_for_retest') and (admin or (dev and b.assigned_developer_id=auth.uid())))
  or (p_status in ('reopened','closed') and (admin or (qa and public.pmt_app_member(b.application_id))))
 ) then raise exception 'Not authorized for this status' using errcode='42501'; end if;
 if p_status in ('in_progress','pending','not_a_bug','ready_for_retest') and b.status not in ('open','reopened','in_progress','pending','not_a_bug') then raise exception 'Bug must first be reopened or assigned'; end if;
 if p_status in ('pending','not_a_bug','ready_for_retest') and nullif(trim(coalesce(p_reason,'')),'') is null then raise exception 'Reason or resolution notes required'; end if;
 if p_status='ready_for_retest' then
  if p_fixed_build_id is null or not exists(select 1 from public.builds f where f.id=p_fixed_build_id and f.application_id=b.application_id and f.id<>b.affected_build_id) then
  raise exception 'Valid fixed build from the same application required'; end if;
 end if;
 if p_status in ('closed','reopened') then
  if b.status<>'ready_for_retest' then raise exception 'Bug must be ready for retest'; end if;
  if not exists(select 1 from public.bug_retests t where t.bug_id=b.id and t.build_id=b.fixed_build_id and
    t.outcome=case when p_status='closed' then 'passed' else 'failed' end)
  then raise exception 'Matching QA retest result required'; end if;
 end if;
 update public.bugs set status=p_status,
 pending_reason=case when p_status in ('pending','not_a_bug') then p_reason else pending_reason end,
 resolution_notes=case when p_status='ready_for_retest' then p_reason else resolution_notes end,
 fixed_build_id=case when p_status='ready_for_retest' then p_fixed_build_id else fixed_build_id end,
 closed_at=case when p_status='closed' then now() else closed_at end,
 updated_at=now() where id=p_bug_id;
 insert into public.bug_status_history(bug_id,changed_by,from_status,to_status,reason) values(p_bug_id,auth.uid(),b.status,p_status,p_reason);
 insert into public.activity_logs(actor_id,bug_id,event_type,old_data,new_data) values(auth.uid(),p_bug_id,'bug_status_changed',jsonb_build_object('status',b.status),jsonb_build_object('status',p_status,'fixed_build_id',p_fixed_build_id));
 if p_status='ready_for_retest' then
   select ba.qa_user_id into v_next_qa from public.build_assignments ba where ba.build_id=p_fixed_build_id and ba.revoked_at is null order by ba.assigned_at desc limit 1;
   if v_next_qa is not null then insert into public.notifications(recipient_id,event_type,bug_id,build_id,message) values(v_next_qa,'bug_ready_for_retest',p_bug_id,p_fixed_build_id,'Bug is ready for QA retesting'); end if;
 elsif p_status in ('reopened','closed') and b.assigned_developer_id is not null then
   insert into public.notifications(recipient_id,event_type,bug_id,message) values(b.assigned_developer_id,'bug_'||p_status,p_bug_id,'Bug marked '||p_status);
 end if;
 return p_status;
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_comment_created_audit()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
begin
 insert into public.activity_logs(actor_id,bug_id,event_type,new_data)
 values(new.author_id,new.bug_id,'bug_comment_added',jsonb_build_object('comment_id',new.id));
 return new;
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_guard_bug_code()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
begin
 if tg_op='INSERT' then
   new.bug_code := 'BUG-' || extract(year from now())::int::text || '-' || lpad(nextval('public.pmt_bug_seq')::text,6,'0');
 elsif new.bug_code is distinct from old.bug_code then
   raise exception 'Bug ID cannot be changed';
 end if;
 return new;
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_guard_workflow_columns()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
begin
 if current_user in ('authenticated','anon') then
  if tg_table_name='bugs' and (
   new.status is distinct from old.status or
   new.assigned_developer_id is distinct from old.assigned_developer_id or
   new.fixed_build_id is distinct from old.fixed_build_id or
   new.closed_at is distinct from old.closed_at
  ) then raise exception 'Use PMT controlled workflow action' using errcode='42501'; end if;
  if tg_table_name='builds' and (
   new.status is distinct from old.status or
   new.application_id is distinct from old.application_id or
   new.version_code is distinct from old.version_code or
   new.drive_file_id is distinct from old.drive_file_id
  ) then raise exception 'Protected build fields cannot be edited directly' using errcode='42501'; end if;
 end if;
 return new;
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_is_admin()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and p.is_active) $function$
;
CREATE OR REPLACE FUNCTION public.pmt_is_dev()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='developer' and p.is_active) $function$
;
CREATE OR REPLACE FUNCTION public.pmt_is_qa()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='qa' and p.is_active) $function$
;
CREATE OR REPLACE FUNCTION public.pmt_profile_after_signup()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
begin
 insert into public.profiles(id,email,full_name,role,is_active)
 values(new.id,new.email,coalesce(new.raw_user_meta_data->>'full_name',''),'developer',true)
 on conflict(id) do nothing;
 return new;
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_project_member(project uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$ select exists(select 1 from public.project_members m join public.profiles p on p.id=m.user_id where m.project_id=project and m.user_id=auth.uid() and p.is_active) $function$
;
CREATE OR REPLACE FUNCTION public.pmt_record_creation()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
begin
 if tg_table_name='projects' then
  insert into public.activity_logs(actor_id,project_id,event_type,new_data) values(new.created_by,new.id,'project_created',jsonb_build_object('name',new.project_name));
 elsif tg_table_name='builds' then
  insert into public.activity_logs(actor_id,build_id,event_type,new_data) values(new.uploaded_by,new.id,'build_registered',jsonb_build_object('version',new.version_name,'code',new.version_code));
 elsif tg_table_name='bugs' then
  insert into public.activity_logs(actor_id,bug_id,event_type,new_data) values(new.reported_by,new.id,'bug_created',jsonb_build_object('bug_code',new.bug_code,'title',new.title));
  insert into public.bug_status_history(bug_id,changed_by,from_status,to_status) values(new.id,new.reported_by,null,'open');
 end if;
 return new;
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_record_qa_result(p_build_id uuid, p_result text, p_notes text DEFAULT NULL::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare b public.builds%rowtype; v_session uuid; v_qa uuid;
begin
 if auth.uid() is null then raise exception 'Login required' using errcode='42501'; end if;
 if p_result not in ('in_progress','passed','failed','blocked') then raise exception 'Invalid test result'; end if;
 select * into b from public.builds where id=p_build_id for update;
 if not found then raise exception 'Build not found'; end if;
 if b.status='archived' then raise exception 'Cannot test archived build'; end if;
 if not public.pmt_is_admin() then
  if not public.pmt_is_qa() or not public.pmt_build_member(p_build_id) or not exists(
   select 1 from public.build_assignments ba where ba.build_id=p_build_id and ba.qa_user_id=auth.uid() and ba.revoked_at is null
  ) then raise exception 'Assigned QA access required' using errcode='42501'; end if;
 end if;
 if public.pmt_is_admin() then
   select ba.qa_user_id into v_qa from public.build_assignments ba where ba.build_id=p_build_id and ba.revoked_at is null order by ba.assigned_at desc limit 1;
   if v_qa is null then raise exception 'Assign this build to QA before recording a result'; end if;
 else v_qa:=auth.uid();
 end if;
 insert into public.test_sessions(build_id,qa_user_id,result,notes,started_at,completed_at)
 values(p_build_id,v_qa,p_result,p_notes,now(),case when p_result='in_progress' then null else now() end)
 returning id into v_session;
 update public.builds
 set status=case p_result when 'in_progress' then 'testing' when 'passed' then 'qa_passed' when 'failed' then 'qa_failed' else 'testing' end,
 updated_at=now() where id=p_build_id;
 insert into public.activity_logs(actor_id,build_id,event_type,new_data)
 values(auth.uid(),p_build_id,'qa_result_recorded',jsonb_build_object('result',p_result,'session_id',v_session));
 return v_session;
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_reopen_closed_bug(p_bug_id uuid, p_reason text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare v_bug public.bugs%rowtype; v_log uuid;
begin
 if auth.uid() is null or not public.pmt_is_admin() then
   raise exception 'Only Admin may reopen a closed bug' using errcode='42501';
 end if;
 if nullif(btrim(coalesce(p_reason,'')),'') is null then
   raise exception 'A reopening reason is required';
 end if;
 select * into v_bug from public.bugs where id=p_bug_id for update;
 if not found then raise exception 'Bug not found'; end if;
 if v_bug.status<>'closed' then raise exception 'Only closed bugs can use this action'; end if;
 update public.bugs
   set status='reopened', closed_at=null, updated_at=now()
   where id=p_bug_id;
 insert into public.bug_status_history(bug_id,changed_by,from_status,to_status,reason)
 values(p_bug_id,auth.uid(),'closed','reopened',p_reason)
 returning id into v_log;
 insert into public.activity_logs(actor_id,bug_id,event_type,old_data,new_data)
 values(auth.uid(),p_bug_id,'closed_bug_reopened',
 jsonb_build_object('status','closed'),
 jsonb_build_object('status','reopened','reason',p_reason));
 if v_bug.assigned_developer_id is not null then
  insert into public.notifications(recipient_id,event_type,bug_id,message)
  values(v_bug.assigned_developer_id,'bug_reopened',p_bug_id,'A closed bug was reopened by Admin');
 end if;
 return v_log;
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_review_not_a_bug(p_bug_id uuid, p_accept boolean, p_reason text)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare b public.bugs%rowtype;
begin
 if auth.uid() is null or not (public.pmt_is_admin() or
  (public.pmt_is_qa() and exists(select 1 from public.bugs x where x.id=p_bug_id and x.reported_by=auth.uid())))
 then raise exception 'QA reporter or Admin authorization required' using errcode='42501'; end if;
 if nullif(btrim(coalesce(p_reason,'')),'') is null then raise exception 'Review reason required'; end if;
 select * into b from public.bugs where id=p_bug_id for update;
 if not found or b.status<>'not_a_bug' then raise exception 'Bug is not awaiting Not a Bug review'; end if;
 if p_accept then
  insert into public.activity_logs(actor_id,bug_id,event_type,new_data)
  values(auth.uid(),p_bug_id,'not_a_bug_accepted',jsonb_build_object('reason',p_reason));
  return 'not_a_bug';
 end if;
 update public.bugs set status='reopened',updated_at=now() where id=p_bug_id;
 insert into public.bug_status_history(bug_id,changed_by,from_status,to_status,reason)
 values(p_bug_id,auth.uid(),'not_a_bug','reopened',p_reason);
 insert into public.activity_logs(actor_id,bug_id,event_type,new_data)
 values(auth.uid(),p_bug_id,'not_a_bug_rejected',jsonb_build_object('reason',p_reason));
 if b.assigned_developer_id is not null then
  insert into public.notifications(recipient_id,event_type,bug_id,message)
  values(b.assigned_developer_id,'bug_reopened',p_bug_id,'QA/Admin rejected Not a Bug decision');
 end if;
 return 'reopened';
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_submit_retest(p_bug_id uuid, p_build_id uuid, p_outcome text, p_notes text DEFAULT NULL::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare b public.bugs%rowtype; v_id uuid;
begin
 if auth.uid() is null or not (public.pmt_is_qa() or public.pmt_is_admin()) then raise exception 'QA/Admin required' using errcode='42501'; end if;
 select * into b from public.bugs where id=p_bug_id for update;
 if not found or b.status<>'ready_for_retest' or b.fixed_build_id is distinct from p_build_id then raise exception 'Bug not awaiting this build retest'; end if;
 if p_outcome not in ('passed','failed','blocked') then raise exception 'Invalid retest result'; end if;
 if not public.pmt_is_admin() and (not public.pmt_app_member(b.application_id) or not exists(
  select 1 from public.build_assignments ba where ba.build_id=p_build_id and ba.qa_user_id=auth.uid() and ba.revoked_at is null))
 then raise exception 'QA is not assigned to fixed build' using errcode='42501'; end if;
 insert into public.bug_retests(bug_id,build_id,qa_user_id,outcome,notes) values(p_bug_id,p_build_id,auth.uid(),p_outcome,p_notes) returning id into v_id;
 insert into public.activity_logs(actor_id,bug_id,build_id,event_type,new_data) values(auth.uid(),p_bug_id,p_build_id,'bug_retested',jsonb_build_object('outcome',p_outcome,'notes',p_notes));
 return v_id;
end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_touch_updated_at()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
begin new.updated_at=now(); return new; end $function$
;
CREATE OR REPLACE FUNCTION public.pmt_validate_bug_builds()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
begin
 if not exists(select 1 from public.builds b where b.id=new.affected_build_id and b.application_id=new.application_id)
 then raise exception 'Affected build must belong to the bug application'; end if;
 if new.fixed_build_id is not null and not exists(select 1 from public.builds b where b.id=new.fixed_build_id and b.application_id=new.application_id and b.id<>new.affected_build_id)
 then raise exception 'Fixed build must be a different build from the same application'; end if;
 if tg_op='UPDATE' then
  if new.affected_build_id is distinct from old.affected_build_id or new.application_id is distinct from old.application_id
  then raise exception 'Original bug application and affected build cannot change'; end if;
 end if;
 return new;
end $function$
;
CREATE INDEX pmt_members_user_idx ON public.project_members USING btree (user_id);
CREATE INDEX pmt_builds_app_idx ON public.builds USING btree (application_id, created_at DESC);
CREATE INDEX pmt_buildassign_qa_idx ON public.build_assignments USING btree (qa_user_id, assigned_at DESC);
CREATE INDEX pmt_tests_build_idx ON public.test_sessions USING btree (build_id, created_at DESC);
CREATE INDEX pmt_bugs_app_idx ON public.bugs USING btree (application_id, status);
CREATE INDEX pmt_bugs_assigned_idx ON public.bugs USING btree (assigned_developer_id, status);
CREATE INDEX pmt_bugs_build_idx ON public.bugs USING btree (affected_build_id);
CREATE INDEX pmt_comments_bug_idx ON public.bug_comments USING btree (bug_id, created_at);
CREATE INDEX pmt_retests_bug_idx ON public.bug_retests USING btree (bug_id, retested_at DESC);
CREATE INDEX pmt_notifications_user_idx ON public.notifications USING btree (recipient_id, is_read, created_at DESC);
CREATE INDEX pmt_logs_bug_idx ON public.activity_logs USING btree (bug_id, occurred_at DESC);
CREATE TRIGGER pmt_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION pmt_profile_after_signup();
CREATE TRIGGER pmt_bugs_guard_code BEFORE INSERT OR UPDATE ON public.bugs FOR EACH ROW EXECUTE FUNCTION pmt_guard_bug_code();
CREATE TRIGGER pmt_projects_updated_at BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION pmt_touch_updated_at();
CREATE TRIGGER pmt_applications_updated_at BEFORE UPDATE ON public.applications FOR EACH ROW EXECUTE FUNCTION pmt_touch_updated_at();
CREATE TRIGGER pmt_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION pmt_touch_updated_at();
CREATE TRIGGER pmt_builds_updated_at BEFORE UPDATE ON public.builds FOR EACH ROW EXECUTE FUNCTION pmt_touch_updated_at();
CREATE TRIGGER pmt_bugs_updated_at BEFORE UPDATE ON public.bugs FOR EACH ROW EXECUTE FUNCTION pmt_touch_updated_at();
CREATE TRIGGER pmt_bugs_build_consistency BEFORE INSERT OR UPDATE ON public.bugs FOR EACH ROW EXECUTE FUNCTION pmt_validate_bug_builds();
CREATE TRIGGER pmt_guard_bug_workflow BEFORE UPDATE ON public.bugs FOR EACH ROW EXECUTE FUNCTION pmt_guard_workflow_columns();
CREATE TRIGGER pmt_guard_build_workflow BEFORE UPDATE ON public.builds FOR EACH ROW EXECUTE FUNCTION pmt_guard_workflow_columns();
CREATE TRIGGER pmt_projects_create_audit AFTER INSERT ON public.projects FOR EACH ROW EXECUTE FUNCTION pmt_record_creation();
CREATE TRIGGER pmt_builds_create_audit AFTER INSERT ON public.builds FOR EACH ROW EXECUTE FUNCTION pmt_record_creation();
CREATE TRIGGER pmt_bugs_create_audit AFTER INSERT ON public.bugs FOR EACH ROW EXECUTE FUNCTION pmt_record_creation();
CREATE TRIGGER pmt_bug_comment_created_audit AFTER INSERT ON public.bug_comments FOR EACH ROW EXECUTE FUNCTION pmt_comment_created_audit();
CREATE TRIGGER pmt_bug_attachment_create_audit AFTER INSERT ON public.bug_attachments FOR EACH ROW EXECUTE FUNCTION pmt_audit_attachment_created();
ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bug_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bug_attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bug_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bug_retests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bug_status_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bugs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.build_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.build_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.builds ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.project_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.test_sessions ENABLE ROW LEVEL SECURITY;
INSERT INTO storage.buckets(id,name,public,file_size_limit,allowed_mime_types) VALUES ('bug-screenshots','bug-screenshots',false,10485760,array['image/png','image/jpeg','image/webp']),('bug-videos','bug-videos',false,52428800,array['video/mp4','video/webm']);
CREATE POLICY pmt_read_profiles ON public.profiles FOR SELECT TO authenticated USING (((id = auth.uid()) OR pmt_is_admin() OR (EXISTS ( SELECT 1
   FROM project_members pm
  WHERE ((pm.user_id = profiles.id) AND pmt_project_member(pm.project_id))))));
CREATE POLICY pmt_read_projects ON public.projects FOR SELECT TO authenticated USING ((pmt_project_member(id) OR pmt_is_admin()));
CREATE POLICY pmt_read_applications ON public.applications FOR SELECT TO authenticated USING ((pmt_project_member(project_id) OR pmt_is_admin()));
CREATE POLICY pmt_read_project_members ON public.project_members FOR SELECT TO authenticated USING ((pmt_project_member(project_id) OR pmt_is_admin()));
CREATE POLICY pmt_read_builds ON public.builds FOR SELECT TO authenticated USING ((pmt_app_member(application_id) OR pmt_is_admin()));
CREATE POLICY pmt_read_build_assignments ON public.build_assignments FOR SELECT TO authenticated USING ((pmt_build_member(build_id) OR pmt_is_admin()));
CREATE POLICY pmt_read_test_sessions ON public.test_sessions FOR SELECT TO authenticated USING ((pmt_build_member(build_id) OR pmt_is_admin()));
CREATE POLICY pmt_read_bugs ON public.bugs FOR SELECT TO authenticated USING ((pmt_app_member(application_id) OR pmt_is_admin()));
CREATE POLICY pmt_read_bug_assignments ON public.bug_assignments FOR SELECT TO authenticated USING ((pmt_bug_member(bug_id) OR pmt_is_admin()));
CREATE POLICY pmt_read_bug_comments ON public.bug_comments FOR SELECT TO authenticated USING ((pmt_bug_member(bug_id) OR pmt_is_admin()));
CREATE POLICY pmt_read_bug_attachments ON public.bug_attachments FOR SELECT TO authenticated USING ((pmt_bug_member(bug_id) OR pmt_is_admin()));
CREATE POLICY pmt_read_bug_status_history ON public.bug_status_history FOR SELECT TO authenticated USING ((pmt_bug_member(bug_id) OR pmt_is_admin()));
CREATE POLICY pmt_read_bug_retests ON public.bug_retests FOR SELECT TO authenticated USING ((pmt_bug_member(bug_id) OR pmt_is_admin()));
CREATE POLICY pmt_read_notifications ON public.notifications FOR SELECT TO authenticated USING (((recipient_id = auth.uid()) OR pmt_is_admin()));
CREATE POLICY pmt_read_activity_logs ON public.activity_logs FOR SELECT TO authenticated USING ((pmt_is_admin() OR ((bug_id IS NOT NULL) AND pmt_bug_member(bug_id)) OR ((build_id IS NOT NULL) AND pmt_build_member(build_id)) OR ((project_id IS NOT NULL) AND pmt_project_member(project_id))));
CREATE POLICY pmt_read_build_files ON public.build_files FOR SELECT TO authenticated USING ((pmt_build_member(build_id) OR pmt_is_admin()));
CREATE POLICY pmt_read_app_settings ON public.app_settings FOR SELECT TO authenticated USING (pmt_is_admin());
CREATE POLICY pmt_admin_profiles ON public.profiles FOR ALL TO authenticated USING (pmt_is_admin()) WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_admin_projects ON public.projects FOR ALL TO authenticated USING (pmt_is_admin()) WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_admin_applications ON public.applications FOR ALL TO authenticated USING (pmt_is_admin()) WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_admin_project_members ON public.project_members FOR ALL TO authenticated USING (pmt_is_admin()) WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_admin_build_assignments ON public.build_assignments FOR ALL TO authenticated USING (pmt_is_admin()) WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_admin_bug_assignments ON public.bug_assignments FOR ALL TO authenticated USING (pmt_is_admin()) WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_admin_bug_attachments ON public.bug_attachments FOR ALL TO authenticated USING (pmt_is_admin()) WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_admin_notifications ON public.notifications FOR ALL TO authenticated USING (pmt_is_admin()) WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_admin_app_settings ON public.app_settings FOR ALL TO authenticated USING (pmt_is_admin()) WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_dev_build_insert ON public.builds FOR INSERT TO authenticated WITH CHECK ((pmt_is_dev() AND pmt_app_member(application_id) AND (uploaded_by = auth.uid()) AND (status = 'uploaded'::text)));
CREATE POLICY pmt_dev_buildfile_insert ON public.build_files FOR INSERT TO authenticated WITH CHECK ((pmt_is_dev() AND pmt_build_member(build_id) AND (recorded_by = auth.uid())));
CREATE POLICY pmt_admin_bugs_write ON public.bugs FOR UPDATE TO authenticated USING (pmt_is_admin()) WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_qa_bug_insert ON public.bugs FOR INSERT TO authenticated WITH CHECK ((pmt_is_qa() AND (reported_by = auth.uid()) AND pmt_app_member(application_id) AND (EXISTS ( SELECT 1
   FROM builds b
  WHERE ((b.id = bugs.affected_build_id) AND (b.application_id = bugs.application_id)))) AND (status = 'open'::text) AND (fixed_build_id IS NULL) AND (assigned_developer_id IS NULL)));
CREATE POLICY pmt_member_comment_insert ON public.bug_comments FOR INSERT TO authenticated WITH CHECK ((pmt_bug_member(bug_id) AND (author_id = auth.uid())));
CREATE POLICY pmt_qa_attachment_insert ON public.bug_attachments FOR INSERT TO authenticated WITH CHECK ((pmt_is_qa() AND pmt_bug_member(bug_id) AND (uploaded_by = auth.uid())));
CREATE POLICY pmt_user_notification_readmark ON public.notifications FOR UPDATE TO authenticated USING ((recipient_id = auth.uid())) WITH CHECK ((recipient_id = auth.uid()));
CREATE POLICY pmt_attachment_read ON storage.objects FOR SELECT TO authenticated USING (((bucket_id = ANY (ARRAY['bug-screenshots'::text, 'bug-videos'::text])) AND (pmt_is_admin() OR ((name ~ '^[0-9a-f-]{36}/[0-9a-f-]{36}/'::text) AND pmt_bug_member((split_part(name, '/'::text, 1))::uuid)))));
CREATE POLICY pmt_attachment_upload ON storage.objects FOR INSERT TO authenticated WITH CHECK (((bucket_id = ANY (ARRAY['bug-screenshots'::text, 'bug-videos'::text])) AND (name ~ '^[0-9a-f-]{36}/[0-9a-f-]{36}/'::text) AND (split_part(name, '/'::text, 2) = (auth.uid())::text) AND (pmt_is_admin() OR (pmt_is_qa() AND pmt_bug_member((split_part(name, '/'::text, 1))::uuid)))));
CREATE POLICY pmt_admin_activity_logs_insert ON public.activity_logs FOR INSERT TO authenticated WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_admin_bug_status_history_insert ON public.bug_status_history FOR INSERT TO authenticated WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_admin_bug_comments_insert ON public.bug_comments FOR INSERT TO authenticated WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_admin_build_files_insert ON public.build_files FOR INSERT TO authenticated WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_admin_bugs_insert ON public.bugs FOR INSERT TO authenticated WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_admin_builds_write ON public.builds FOR UPDATE TO authenticated USING (pmt_is_admin()) WITH CHECK (pmt_is_admin());
CREATE POLICY pmt_admin_builds_insert ON public.builds FOR INSERT TO authenticated WITH CHECK (pmt_is_admin());
GRANT INSERT ON public.profiles TO anon;
GRANT SELECT ON public.profiles TO anon;
GRANT UPDATE ON public.profiles TO anon;
GRANT DELETE ON public.profiles TO anon;
GRANT TRUNCATE ON public.profiles TO anon;
GRANT REFERENCES ON public.profiles TO anon;
GRANT TRIGGER ON public.profiles TO anon;
GRANT INSERT ON public.profiles TO authenticated;
GRANT SELECT ON public.profiles TO authenticated;
GRANT UPDATE ON public.profiles TO authenticated;
GRANT DELETE ON public.profiles TO authenticated;
GRANT TRUNCATE ON public.profiles TO authenticated;
GRANT REFERENCES ON public.profiles TO authenticated;
GRANT TRIGGER ON public.profiles TO authenticated;
GRANT INSERT ON public.profiles TO service_role;
GRANT SELECT ON public.profiles TO service_role;
GRANT UPDATE ON public.profiles TO service_role;
GRANT DELETE ON public.profiles TO service_role;
GRANT TRUNCATE ON public.profiles TO service_role;
GRANT REFERENCES ON public.profiles TO service_role;
GRANT TRIGGER ON public.profiles TO service_role;
GRANT INSERT ON public.projects TO anon;
GRANT SELECT ON public.projects TO anon;
GRANT UPDATE ON public.projects TO anon;
GRANT DELETE ON public.projects TO anon;
GRANT TRUNCATE ON public.projects TO anon;
GRANT REFERENCES ON public.projects TO anon;
GRANT TRIGGER ON public.projects TO anon;
GRANT INSERT ON public.projects TO authenticated;
GRANT SELECT ON public.projects TO authenticated;
GRANT UPDATE ON public.projects TO authenticated;
GRANT DELETE ON public.projects TO authenticated;
GRANT TRUNCATE ON public.projects TO authenticated;
GRANT REFERENCES ON public.projects TO authenticated;
GRANT TRIGGER ON public.projects TO authenticated;
GRANT INSERT ON public.projects TO service_role;
GRANT SELECT ON public.projects TO service_role;
GRANT UPDATE ON public.projects TO service_role;
GRANT DELETE ON public.projects TO service_role;
GRANT TRUNCATE ON public.projects TO service_role;
GRANT REFERENCES ON public.projects TO service_role;
GRANT TRIGGER ON public.projects TO service_role;
GRANT INSERT ON public.applications TO anon;
GRANT SELECT ON public.applications TO anon;
GRANT UPDATE ON public.applications TO anon;
GRANT DELETE ON public.applications TO anon;
GRANT TRUNCATE ON public.applications TO anon;
GRANT REFERENCES ON public.applications TO anon;
GRANT TRIGGER ON public.applications TO anon;
GRANT INSERT ON public.applications TO authenticated;
GRANT SELECT ON public.applications TO authenticated;
GRANT UPDATE ON public.applications TO authenticated;
GRANT DELETE ON public.applications TO authenticated;
GRANT TRUNCATE ON public.applications TO authenticated;
GRANT REFERENCES ON public.applications TO authenticated;
GRANT TRIGGER ON public.applications TO authenticated;
GRANT INSERT ON public.applications TO service_role;
GRANT SELECT ON public.applications TO service_role;
GRANT UPDATE ON public.applications TO service_role;
GRANT DELETE ON public.applications TO service_role;
GRANT TRUNCATE ON public.applications TO service_role;
GRANT REFERENCES ON public.applications TO service_role;
GRANT TRIGGER ON public.applications TO service_role;
GRANT INSERT ON public.project_members TO anon;
GRANT SELECT ON public.project_members TO anon;
GRANT UPDATE ON public.project_members TO anon;
GRANT DELETE ON public.project_members TO anon;
GRANT TRUNCATE ON public.project_members TO anon;
GRANT REFERENCES ON public.project_members TO anon;
GRANT TRIGGER ON public.project_members TO anon;
GRANT INSERT ON public.project_members TO authenticated;
GRANT SELECT ON public.project_members TO authenticated;
GRANT UPDATE ON public.project_members TO authenticated;
GRANT DELETE ON public.project_members TO authenticated;
GRANT TRUNCATE ON public.project_members TO authenticated;
GRANT REFERENCES ON public.project_members TO authenticated;
GRANT TRIGGER ON public.project_members TO authenticated;
GRANT INSERT ON public.project_members TO service_role;
GRANT SELECT ON public.project_members TO service_role;
GRANT UPDATE ON public.project_members TO service_role;
GRANT DELETE ON public.project_members TO service_role;
GRANT TRUNCATE ON public.project_members TO service_role;
GRANT REFERENCES ON public.project_members TO service_role;
GRANT TRIGGER ON public.project_members TO service_role;
GRANT INSERT ON public.notifications TO anon;
GRANT SELECT ON public.notifications TO anon;
GRANT UPDATE ON public.notifications TO anon;
GRANT DELETE ON public.notifications TO anon;
GRANT TRUNCATE ON public.notifications TO anon;
GRANT REFERENCES ON public.notifications TO anon;
GRANT TRIGGER ON public.notifications TO anon;
GRANT INSERT ON public.notifications TO authenticated;
GRANT SELECT ON public.notifications TO authenticated;
GRANT DELETE ON public.notifications TO authenticated;
GRANT TRUNCATE ON public.notifications TO authenticated;
GRANT REFERENCES ON public.notifications TO authenticated;
GRANT TRIGGER ON public.notifications TO authenticated;
GRANT INSERT ON public.notifications TO service_role;
GRANT SELECT ON public.notifications TO service_role;
GRANT UPDATE ON public.notifications TO service_role;
GRANT DELETE ON public.notifications TO service_role;
GRANT TRUNCATE ON public.notifications TO service_role;
GRANT REFERENCES ON public.notifications TO service_role;
GRANT TRIGGER ON public.notifications TO service_role;
GRANT INSERT ON public.builds TO anon;
GRANT SELECT ON public.builds TO anon;
GRANT UPDATE ON public.builds TO anon;
GRANT DELETE ON public.builds TO anon;
GRANT TRUNCATE ON public.builds TO anon;
GRANT REFERENCES ON public.builds TO anon;
GRANT TRIGGER ON public.builds TO anon;
GRANT INSERT ON public.builds TO authenticated;
GRANT SELECT ON public.builds TO authenticated;
GRANT UPDATE ON public.builds TO authenticated;
GRANT DELETE ON public.builds TO authenticated;
GRANT TRUNCATE ON public.builds TO authenticated;
GRANT REFERENCES ON public.builds TO authenticated;
GRANT TRIGGER ON public.builds TO authenticated;
GRANT INSERT ON public.builds TO service_role;
GRANT SELECT ON public.builds TO service_role;
GRANT UPDATE ON public.builds TO service_role;
GRANT DELETE ON public.builds TO service_role;
GRANT TRUNCATE ON public.builds TO service_role;
GRANT REFERENCES ON public.builds TO service_role;
GRANT TRIGGER ON public.builds TO service_role;
GRANT INSERT ON public.build_assignments TO anon;
GRANT SELECT ON public.build_assignments TO anon;
GRANT UPDATE ON public.build_assignments TO anon;
GRANT DELETE ON public.build_assignments TO anon;
GRANT TRUNCATE ON public.build_assignments TO anon;
GRANT REFERENCES ON public.build_assignments TO anon;
GRANT TRIGGER ON public.build_assignments TO anon;
GRANT INSERT ON public.build_assignments TO authenticated;
GRANT SELECT ON public.build_assignments TO authenticated;
GRANT UPDATE ON public.build_assignments TO authenticated;
GRANT DELETE ON public.build_assignments TO authenticated;
GRANT TRUNCATE ON public.build_assignments TO authenticated;
GRANT REFERENCES ON public.build_assignments TO authenticated;
GRANT TRIGGER ON public.build_assignments TO authenticated;
GRANT INSERT ON public.build_assignments TO service_role;
GRANT SELECT ON public.build_assignments TO service_role;
GRANT UPDATE ON public.build_assignments TO service_role;
GRANT DELETE ON public.build_assignments TO service_role;
GRANT TRUNCATE ON public.build_assignments TO service_role;
GRANT REFERENCES ON public.build_assignments TO service_role;
GRANT TRIGGER ON public.build_assignments TO service_role;
GRANT INSERT ON public.test_sessions TO anon;
GRANT SELECT ON public.test_sessions TO anon;
GRANT UPDATE ON public.test_sessions TO anon;
GRANT DELETE ON public.test_sessions TO anon;
GRANT TRUNCATE ON public.test_sessions TO anon;
GRANT REFERENCES ON public.test_sessions TO anon;
GRANT TRIGGER ON public.test_sessions TO anon;
GRANT INSERT ON public.test_sessions TO authenticated;
GRANT SELECT ON public.test_sessions TO authenticated;
GRANT UPDATE ON public.test_sessions TO authenticated;
GRANT DELETE ON public.test_sessions TO authenticated;
GRANT TRUNCATE ON public.test_sessions TO authenticated;
GRANT REFERENCES ON public.test_sessions TO authenticated;
GRANT TRIGGER ON public.test_sessions TO authenticated;
GRANT INSERT ON public.test_sessions TO service_role;
GRANT SELECT ON public.test_sessions TO service_role;
GRANT UPDATE ON public.test_sessions TO service_role;
GRANT DELETE ON public.test_sessions TO service_role;
GRANT TRUNCATE ON public.test_sessions TO service_role;
GRANT REFERENCES ON public.test_sessions TO service_role;
GRANT TRIGGER ON public.test_sessions TO service_role;
GRANT INSERT ON public.bugs TO anon;
GRANT SELECT ON public.bugs TO anon;
GRANT UPDATE ON public.bugs TO anon;
GRANT DELETE ON public.bugs TO anon;
GRANT TRUNCATE ON public.bugs TO anon;
GRANT REFERENCES ON public.bugs TO anon;
GRANT TRIGGER ON public.bugs TO anon;
GRANT INSERT ON public.bugs TO authenticated;
GRANT SELECT ON public.bugs TO authenticated;
GRANT UPDATE ON public.bugs TO authenticated;
GRANT DELETE ON public.bugs TO authenticated;
GRANT TRUNCATE ON public.bugs TO authenticated;
GRANT REFERENCES ON public.bugs TO authenticated;
GRANT TRIGGER ON public.bugs TO authenticated;
GRANT INSERT ON public.bugs TO service_role;
GRANT SELECT ON public.bugs TO service_role;
GRANT UPDATE ON public.bugs TO service_role;
GRANT DELETE ON public.bugs TO service_role;
GRANT TRUNCATE ON public.bugs TO service_role;
GRANT REFERENCES ON public.bugs TO service_role;
GRANT TRIGGER ON public.bugs TO service_role;
GRANT INSERT ON public.bug_assignments TO anon;
GRANT SELECT ON public.bug_assignments TO anon;
GRANT UPDATE ON public.bug_assignments TO anon;
GRANT DELETE ON public.bug_assignments TO anon;
GRANT TRUNCATE ON public.bug_assignments TO anon;
GRANT REFERENCES ON public.bug_assignments TO anon;
GRANT TRIGGER ON public.bug_assignments TO anon;
GRANT INSERT ON public.bug_assignments TO authenticated;
GRANT SELECT ON public.bug_assignments TO authenticated;
GRANT UPDATE ON public.bug_assignments TO authenticated;
GRANT DELETE ON public.bug_assignments TO authenticated;
GRANT TRUNCATE ON public.bug_assignments TO authenticated;
GRANT REFERENCES ON public.bug_assignments TO authenticated;
GRANT TRIGGER ON public.bug_assignments TO authenticated;
GRANT INSERT ON public.bug_assignments TO service_role;
GRANT SELECT ON public.bug_assignments TO service_role;
GRANT UPDATE ON public.bug_assignments TO service_role;
GRANT DELETE ON public.bug_assignments TO service_role;
GRANT TRUNCATE ON public.bug_assignments TO service_role;
GRANT REFERENCES ON public.bug_assignments TO service_role;
GRANT TRIGGER ON public.bug_assignments TO service_role;
GRANT INSERT ON public.bug_comments TO anon;
GRANT SELECT ON public.bug_comments TO anon;
GRANT UPDATE ON public.bug_comments TO anon;
GRANT DELETE ON public.bug_comments TO anon;
GRANT TRUNCATE ON public.bug_comments TO anon;
GRANT REFERENCES ON public.bug_comments TO anon;
GRANT TRIGGER ON public.bug_comments TO anon;
GRANT INSERT ON public.bug_comments TO authenticated;
GRANT SELECT ON public.bug_comments TO authenticated;
GRANT UPDATE ON public.bug_comments TO authenticated;
GRANT DELETE ON public.bug_comments TO authenticated;
GRANT TRUNCATE ON public.bug_comments TO authenticated;
GRANT REFERENCES ON public.bug_comments TO authenticated;
GRANT TRIGGER ON public.bug_comments TO authenticated;
GRANT INSERT ON public.bug_comments TO service_role;
GRANT SELECT ON public.bug_comments TO service_role;
GRANT UPDATE ON public.bug_comments TO service_role;
GRANT DELETE ON public.bug_comments TO service_role;
GRANT TRUNCATE ON public.bug_comments TO service_role;
GRANT REFERENCES ON public.bug_comments TO service_role;
GRANT TRIGGER ON public.bug_comments TO service_role;
GRANT INSERT ON public.bug_attachments TO anon;
GRANT SELECT ON public.bug_attachments TO anon;
GRANT UPDATE ON public.bug_attachments TO anon;
GRANT DELETE ON public.bug_attachments TO anon;
GRANT TRUNCATE ON public.bug_attachments TO anon;
GRANT REFERENCES ON public.bug_attachments TO anon;
GRANT TRIGGER ON public.bug_attachments TO anon;
GRANT INSERT ON public.bug_attachments TO authenticated;
GRANT SELECT ON public.bug_attachments TO authenticated;
GRANT UPDATE ON public.bug_attachments TO authenticated;
GRANT DELETE ON public.bug_attachments TO authenticated;
GRANT TRUNCATE ON public.bug_attachments TO authenticated;
GRANT REFERENCES ON public.bug_attachments TO authenticated;
GRANT TRIGGER ON public.bug_attachments TO authenticated;
GRANT INSERT ON public.bug_attachments TO service_role;
GRANT SELECT ON public.bug_attachments TO service_role;
GRANT UPDATE ON public.bug_attachments TO service_role;
GRANT DELETE ON public.bug_attachments TO service_role;
GRANT TRUNCATE ON public.bug_attachments TO service_role;
GRANT REFERENCES ON public.bug_attachments TO service_role;
GRANT TRIGGER ON public.bug_attachments TO service_role;
GRANT INSERT ON public.bug_status_history TO anon;
GRANT SELECT ON public.bug_status_history TO anon;
GRANT UPDATE ON public.bug_status_history TO anon;
GRANT DELETE ON public.bug_status_history TO anon;
GRANT TRUNCATE ON public.bug_status_history TO anon;
GRANT REFERENCES ON public.bug_status_history TO anon;
GRANT TRIGGER ON public.bug_status_history TO anon;
GRANT INSERT ON public.bug_status_history TO authenticated;
GRANT SELECT ON public.bug_status_history TO authenticated;
GRANT UPDATE ON public.bug_status_history TO authenticated;
GRANT DELETE ON public.bug_status_history TO authenticated;
GRANT TRUNCATE ON public.bug_status_history TO authenticated;
GRANT REFERENCES ON public.bug_status_history TO authenticated;
GRANT TRIGGER ON public.bug_status_history TO authenticated;
GRANT INSERT ON public.bug_status_history TO service_role;
GRANT SELECT ON public.bug_status_history TO service_role;
GRANT UPDATE ON public.bug_status_history TO service_role;
GRANT DELETE ON public.bug_status_history TO service_role;
GRANT TRUNCATE ON public.bug_status_history TO service_role;
GRANT REFERENCES ON public.bug_status_history TO service_role;
GRANT TRIGGER ON public.bug_status_history TO service_role;
GRANT INSERT ON public.bug_retests TO anon;
GRANT SELECT ON public.bug_retests TO anon;
GRANT UPDATE ON public.bug_retests TO anon;
GRANT DELETE ON public.bug_retests TO anon;
GRANT TRUNCATE ON public.bug_retests TO anon;
GRANT REFERENCES ON public.bug_retests TO anon;
GRANT TRIGGER ON public.bug_retests TO anon;
GRANT INSERT ON public.bug_retests TO authenticated;
GRANT SELECT ON public.bug_retests TO authenticated;
GRANT UPDATE ON public.bug_retests TO authenticated;
GRANT DELETE ON public.bug_retests TO authenticated;
GRANT TRUNCATE ON public.bug_retests TO authenticated;
GRANT REFERENCES ON public.bug_retests TO authenticated;
GRANT TRIGGER ON public.bug_retests TO authenticated;
GRANT INSERT ON public.bug_retests TO service_role;
GRANT SELECT ON public.bug_retests TO service_role;
GRANT UPDATE ON public.bug_retests TO service_role;
GRANT DELETE ON public.bug_retests TO service_role;
GRANT TRUNCATE ON public.bug_retests TO service_role;
GRANT REFERENCES ON public.bug_retests TO service_role;
GRANT TRIGGER ON public.bug_retests TO service_role;
GRANT INSERT ON public.activity_logs TO anon;
GRANT SELECT ON public.activity_logs TO anon;
GRANT UPDATE ON public.activity_logs TO anon;
GRANT DELETE ON public.activity_logs TO anon;
GRANT TRUNCATE ON public.activity_logs TO anon;
GRANT REFERENCES ON public.activity_logs TO anon;
GRANT TRIGGER ON public.activity_logs TO anon;
GRANT INSERT ON public.activity_logs TO authenticated;
GRANT SELECT ON public.activity_logs TO authenticated;
GRANT UPDATE ON public.activity_logs TO authenticated;
GRANT DELETE ON public.activity_logs TO authenticated;
GRANT TRUNCATE ON public.activity_logs TO authenticated;
GRANT REFERENCES ON public.activity_logs TO authenticated;
GRANT TRIGGER ON public.activity_logs TO authenticated;
GRANT INSERT ON public.activity_logs TO service_role;
GRANT SELECT ON public.activity_logs TO service_role;
GRANT UPDATE ON public.activity_logs TO service_role;
GRANT DELETE ON public.activity_logs TO service_role;
GRANT TRUNCATE ON public.activity_logs TO service_role;
GRANT REFERENCES ON public.activity_logs TO service_role;
GRANT TRIGGER ON public.activity_logs TO service_role;
GRANT INSERT ON public.build_files TO anon;
GRANT SELECT ON public.build_files TO anon;
GRANT UPDATE ON public.build_files TO anon;
GRANT DELETE ON public.build_files TO anon;
GRANT TRUNCATE ON public.build_files TO anon;
GRANT REFERENCES ON public.build_files TO anon;
GRANT TRIGGER ON public.build_files TO anon;
GRANT INSERT ON public.build_files TO authenticated;
GRANT SELECT ON public.build_files TO authenticated;
GRANT UPDATE ON public.build_files TO authenticated;
GRANT DELETE ON public.build_files TO authenticated;
GRANT TRUNCATE ON public.build_files TO authenticated;
GRANT REFERENCES ON public.build_files TO authenticated;
GRANT TRIGGER ON public.build_files TO authenticated;
GRANT INSERT ON public.build_files TO service_role;
GRANT SELECT ON public.build_files TO service_role;
GRANT UPDATE ON public.build_files TO service_role;
GRANT DELETE ON public.build_files TO service_role;
GRANT TRUNCATE ON public.build_files TO service_role;
GRANT REFERENCES ON public.build_files TO service_role;
GRANT TRIGGER ON public.build_files TO service_role;
GRANT INSERT ON public.app_settings TO anon;
GRANT SELECT ON public.app_settings TO anon;
GRANT UPDATE ON public.app_settings TO anon;
GRANT DELETE ON public.app_settings TO anon;
GRANT TRUNCATE ON public.app_settings TO anon;
GRANT REFERENCES ON public.app_settings TO anon;
GRANT TRIGGER ON public.app_settings TO anon;
GRANT INSERT ON public.app_settings TO authenticated;
GRANT SELECT ON public.app_settings TO authenticated;
GRANT UPDATE ON public.app_settings TO authenticated;
GRANT DELETE ON public.app_settings TO authenticated;
GRANT TRUNCATE ON public.app_settings TO authenticated;
GRANT REFERENCES ON public.app_settings TO authenticated;
GRANT TRIGGER ON public.app_settings TO authenticated;
GRANT INSERT ON public.app_settings TO service_role;
GRANT SELECT ON public.app_settings TO service_role;
GRANT UPDATE ON public.app_settings TO service_role;
GRANT DELETE ON public.app_settings TO service_role;
GRANT TRUNCATE ON public.app_settings TO service_role;
GRANT REFERENCES ON public.app_settings TO service_role;
GRANT TRIGGER ON public.app_settings TO service_role;
REVOKE ALL ON FUNCTION public.pmt_app_member(app uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_assign_bug(p_bug_id uuid, p_developer_id uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_assign_build(p_build_id uuid, p_qa_id uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_audit_attachment_created() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_bug_member(bug uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_build_member(build uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_change_bug_status(p_bug_id uuid, p_status text, p_reason text, p_fixed_build_id uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_comment_created_audit() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_guard_bug_code() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_guard_workflow_columns() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_is_admin() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_is_dev() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_is_qa() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_profile_after_signup() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_project_member(project uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_record_creation() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_record_qa_result(p_build_id uuid, p_result text, p_notes text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_reopen_closed_bug(p_bug_id uuid, p_reason text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_review_not_a_bug(p_bug_id uuid, p_accept boolean, p_reason text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_submit_retest(p_bug_id uuid, p_build_id uuid, p_outcome text, p_notes text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_touch_updated_at() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pmt_validate_bug_builds() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.pmt_app_member(uuid), public.pmt_assign_bug(uuid,uuid), public.pmt_assign_build(uuid,uuid), public.pmt_bug_member(uuid), public.pmt_build_member(uuid), public.pmt_change_bug_status(uuid,text,text,uuid), public.pmt_is_admin(), public.pmt_is_dev(), public.pmt_is_qa(), public.pmt_project_member(uuid), public.pmt_record_qa_result(uuid,text,text), public.pmt_reopen_closed_bug(uuid,text), public.pmt_review_not_a_bug(uuid,boolean,text), public.pmt_submit_retest(uuid,uuid,text,text) TO authenticated;
commit;


