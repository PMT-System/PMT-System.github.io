-- NOT RUN. Execute only in an isolated test database after the reviewed release.
-- Uses temporary fixture Auth rows and rolls back all changes. Never run against company production.
begin;
insert into auth.users(id,email) values
 ('a0000000-0000-4000-8000-000000000001','chat-admin@example.test'),
 ('a0000000-0000-4000-8000-000000000002','chat-qa@example.test'),
 ('a0000000-0000-4000-8000-000000000003','chat-dev@example.test'),
 ('a0000000-0000-4000-8000-000000000004','chat-outsider@example.test');
update public.profiles set role='admin' where id='a0000000-0000-4000-8000-000000000001';
update public.profiles set role='qa' where id='a0000000-0000-4000-8000-000000000002';
update public.profiles set chat_enabled=true where id in ('a0000000-0000-4000-8000-000000000001','a0000000-0000-4000-8000-000000000002','a0000000-0000-4000-8000-000000000003','a0000000-0000-4000-8000-000000000004');
insert into public.projects(id,project_name) values('b0000000-0000-4000-8000-000000000001','Chat fixture project');
insert into public.project_members(project_id,user_id) values
 ('b0000000-0000-4000-8000-000000000001','a0000000-0000-4000-8000-000000000002'),
 ('b0000000-0000-4000-8000-000000000001','a0000000-0000-4000-8000-000000000003');
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"a0000000-0000-4000-8000-000000000002","role":"authenticated"}',true);
do $$
declare c uuid;d uuid;
begin
 select id into c from public.chat_channels where project_id='b0000000-0000-4000-8000-000000000001';
 if c is null then raise exception 'QA project channel missing'; end if;
 insert into public.chat_messages(channel_id,sender_id,client_nonce,body) values(c,auth.uid(),gen_random_uuid(),'Project fixture');
 d:=public.pmt_open_direct_chat('a0000000-0000-4000-8000-000000000003');
 if d<>public.pmt_open_direct_chat('a0000000-0000-4000-8000-000000000003') then raise exception 'Duplicate DM channel'; end if;
 insert into public.chat_messages(channel_id,sender_id,client_nonce,body) values(d,auth.uid(),gen_random_uuid(),'Private fixture');
 begin
  insert into public.chat_messages(channel_id,sender_id,client_nonce,body) values(c,'a0000000-0000-4000-8000-000000000003',gen_random_uuid(),'Forged sender');
  raise exception 'Sender spoofing was allowed';
 exception when insufficient_privilege then null; end;
 begin
  update public.chat_messages set body='Modified history' where channel_id=c;
  raise exception 'Message history mutation was allowed';
 exception when insufficient_privilege then null; end;
end $$;
select set_config('request.jwt.claims','{"sub":"a0000000-0000-4000-8000-000000000004","role":"authenticated"}',true);
do $$begin
 if exists(select 1 from public.chat_channels where project_id='b0000000-0000-4000-8000-000000000001') then raise exception 'Outsider can read project channel'; end if;
 if exists(select 1 from public.chat_messages where body in ('Project fixture','Private fixture')) then raise exception 'Outsider can read messages'; end if;
 if not exists(select 1 from public.chat_channels where kind='team') then raise exception 'Active company user cannot access team channel'; end if;
end $$;
select set_config('request.jwt.claims','{"sub":"a0000000-0000-4000-8000-000000000001","role":"authenticated"}',true);
do $$begin
 if exists(select 1 from public.chat_messages where body='Private fixture') then raise exception 'Non-participant Admin can read a private DM'; end if;
end $$;
reset role;
delete from public.project_members where project_id='b0000000-0000-4000-8000-000000000001' and user_id='a0000000-0000-4000-8000-000000000002';
update public.profiles set is_active=false where id='a0000000-0000-4000-8000-000000000004';
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"a0000000-0000-4000-8000-000000000002","role":"authenticated"}',true);
do $$begin
 if exists(select 1 from public.chat_messages where body='Project fixture') then raise exception 'Removed member retained project access'; end if;
end $$;
select set_config('request.jwt.claims','{"sub":"a0000000-0000-4000-8000-000000000004","role":"authenticated"}',true);
do $$begin
 if exists(select 1 from public.chat_channels) then raise exception 'Inactive user retained chat access'; end if;
end $$;
reset role;
update public.profiles set is_active=true,chat_enabled=false where id='a0000000-0000-4000-8000-000000000004';
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"a0000000-0000-4000-8000-000000000004","role":"authenticated"}',true);
do $$begin
 if exists(select 1 from public.chat_channels) then raise exception 'Unapproved active signup entered company chat'; end if;
end $$;
rollback;
