import {readFile,writeFile} from 'node:fs/promises';
const files=['upgrade.sql','additional.sql','retest-hardening.sql','archive.sql','reference-validation.sql','chat.sql','access-hardening.sql'];
const guard=`DO $preflight$ BEGIN
 IF (SELECT count(*) FROM public.profiles)<>1 OR EXISTS(SELECT 1 FROM public.projects) OR EXISTS(SELECT 1 FROM public.builds) OR EXISTS(SELECT 1 FROM public.bugs) THEN RAISE EXCEPTION 'Project changed since preflight; stop for review'; END IF;
END $preflight$;`;
const parts=await Promise.all(files.map(async f=>'\n-- '+f+'\n'+(await readFile('backend/'+f,'utf8')).replace(/^begin;\s*$/gmi,'').replace(/^commit;\s*$/gmi,'')));
await writeFile('backend/release.sql','-- Reviewed proposal; live application blocked by automatic approval review.\n-- No operational reports are deleted.\nbegin;\n'+guard+parts.join('\n')+'\ncommit;\n');
