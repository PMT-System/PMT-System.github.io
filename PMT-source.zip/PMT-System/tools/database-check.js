// Local PostgreSQL/WASM only. No network, live credentials or production database.
import {PGlite} from '@electric-sql/pglite';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
const pg=await PGlite.create();
try{
 await pg.exec(`
 create role anon nologin;create role authenticated nologin;create role service_role nologin bypassrls;
 create schema auth;create schema storage;
 create table auth.users(id uuid primary key,email text,raw_user_meta_data jsonb default '{}');
 create function auth.uid() returns uuid language sql stable as $$select (nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'sub')::uuid$$;
 `);
 await pg.exec(`create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
 create table storage.objects(id uuid primary key default gen_random_uuid(),bucket_id text references storage.buckets(id),name text,metadata jsonb);
 alter table storage.objects enable row level security;
 grant usage on schema public,auth,storage to anon,authenticated,service_role;
 grant select on auth.users to authenticated;
 grant select,insert,update,delete on storage.objects to authenticated,service_role;
 alter default privileges in schema public grant all on tables to anon,authenticated,service_role;
 alter default privileges in schema public grant all on sequences to service_role;
 `);
 await pg.exec(await readFile('backend/baseline.sql','utf8'));
 console.log('PASS existing baseline schema restored locally');
 await pg.exec(`insert into auth.users(id,email)values('90000000-0000-4000-8000-000000000001','preserve-admin@example.test');update public.profiles set role='admin',full_name='Preserved Admin' where id='90000000-0000-4000-8000-000000000001';`);
 await pg.exec(await readFile('backend/release.sql','utf8'));
 const preserved=await pg.query("select full_name,role,is_active,chat_enabled from public.profiles where id='90000000-0000-4000-8000-000000000001'");
 if(preserved.rows[0]?.full_name!=='Preserved Admin'||preserved.rows[0]?.role!=='admin'||!preserved.rows[0].chat_enabled)throw Error('Existing Admin not preserved');
 console.log('PASS entire release migration executes and preserves existing Admin');
 await pg.exec(await readFile('backend/chat-tests.sql','utf8'));
 console.log('PASS PostgreSQL chat access tests: project membership, private DM, spoofing, immutable messages, removed member, inactive and unapproved accounts');
 await pg.exec(await readFile('backend/workflow-tests.sql','utf8'));
 console.log('PASS PostgreSQL workflow tests: private developer assignments, immutable report time, required reasons/builds, QA closure, stale retest rejection, reopen and history');
 await mkdir('test-results',{recursive:true});
 await writeFile('test-results/database.json',JSON.stringify({engine:'PGlite 0.5.10 / PostgreSQL WASM; simulated Supabase Auth and Storage schemas',baseline:'pass',migration:'pass',existing_admin_preserved:true,chat_security:'pass',bug_workflows:'pass',live_supabase_tested:false},null,2));
}catch(error){console.error('DATABASE CHECK FAILED:',error.message,'\n',error.detail||'',error.where||'');process.exitCode=1;}finally{await pg.close();}
