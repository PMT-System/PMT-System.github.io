# Verification and release blockers

16 October 2026. **Not production complete.**

## Executed successfully

- Existing project healthy; 17 public base tables inspected; all have RLS enabled.
- Existing functions, policies, constraints and Storage bucket metadata inspected; no user passwords or backend secrets exported.
- 14 automated tests: CSV quoting/formula defense, complete pagination over 1,251 records, HTML escaping, Pakistan-time formatting, APK ZIP/manifest validation and SHA-256; isolated service authentication, inactive-account denial, Admin action denial, size rejection, unavailable-AI handling and quota fallback; chat channel labels and untrusted-message escaping.
- JavaScript syntax checks for frontend files and TypeScript syntax check for the Edge handler.
- Headless Edge fixture tests: anonymous login; mobile login and all three role dashboards at 390px with no horizontal overflow; Admin/QA/Developer navigation; Admin menu visibility; QA bug does not save until explicit approval; reported date/time display includes PKT; unsaved bug draft survives refresh. All three roles also exercised full-team, project and private chat sends, room separation, reload persistence, mobile chat layout and reconciliation after a lost save response. Browser JavaScript errors: none in those tested flows.
- Desktop dashboard and mobile login screenshots inspected. They contain clearly labelled fixture records, not production data.

## Not executed / blocked

| Check | Status / reason |
|---|---|
| Live chat RLS / sender spoofing / membership revocation | Passed in local PostgreSQL; live Supabase still blocked |
| Apply SQL upgrade | Automatic approval review rejected broad live policy/grant/constraint changes; database unchanged |
| SQL baseline restore and upgrade execution | Passed in local PGlite/PostgreSQL with simulated Supabase Auth/Storage schemas; not applied live |
| Real Admin/QA/Developer login and refresh | Not tested with company accounts |
| Live project/member/create/edit/role changes | Not tested |
| Direct REST IDOR/RLS and role-escalation attacks | Not executed against upgraded schema |
| Real 50–200 MB APK upload/checksum/download | Not tested; no test APK or configured company Drive credentials |
| Two-build retention and deletion retries | Implemented locally; transaction/concurrency/security testing outstanding |
| Private screenshot/video/report upload/download/delete | Implemented locally; not tested against live Storage policies |
| Bug assignment, notifications and full status lifecycle | Implemented locally / existing RPCs reused; not live verified |
| Retest current-cycle validity | Passed locally: QA closure, failed retest reopening and rejection of an old-cycle retest; live checks outstanding |
| Admin editing/deleting all file/record types | Core edits, archival/restore and APK/evidence file removal implemented locally. Physical database report deletion is intentionally not exposed; records/history are retained |
| Build metadata editing/archive controls | Admin metadata edit and archive/restore added locally; not live tested |
| Filtering by every requested dimension | Search/status/app/priority/severity/project/developer/build ID/reported date implemented. Assignment-date filtering remains |
| Notifications automatic refresh | Manual refresh plus foreground notification poll every 60 seconds implemented; live delivery not tested |
| Draft recovery after browser refresh | New bug/summary text drafts restored from tab-scoped session storage; files require reselection. Bug draft refresh recovery browser test passed; summary recovery uses the same mechanism but was not separately exercised |
| Google Drive resumable upload/CORS/token expiry | Not tested; company OAuth secrets absent |
| Real AI translation/summary/free quotas | No real provider calls; keys and provider/model approval absent. Only Gemini/Groq adapters implemented |
| Provider quota enforcement / cost guarantees | Application flags do not control provider billing; paid billing must remain disabled at provider |
| GitHub push / Pages deployment | Not attempted; backend release blocked; write authentication not verified |
| End-to-end browser persistence and mobile full workflows | Not executed against live backend |
| Backup restoration | Not tested |

## Existing security advisory findings

The live advisor reports 14 authenticated-executable SECURITY DEFINER helpers/RPCs and disabled leaked-password protection. The former requires review of authorization in every function and preferably private helper organization; it is not proof each function is exploitable. Leaked-password protection is unavailable on the chosen free plan, according to current pricing; do not enable a paid plan automatically.

## Required release test matrix

Use separate test Admin, QA, assigned Developer and non-member Developer accounts. Test all endpoints directly as well as through the UI. Label created fixtures clearly and remove only temporary records with explicit scope; do not erase existing company history.

1. Anonymous requests must fail for all private tables, file downloads and service operations.
2. Non-member user must not access another project's application/build/bug/evidence by substituting IDs.
3. Developer A must not read Developer B's private bug, comments, assignment, history, CSV or evidence, even in the same project.
4. QA must not change another QA's report, immutable reported time, reporter, assignment, status or fixed-build fields through direct REST writes.
5. Only Admin can create accounts/change roles; public sign-up cannot become Admin; inactive accounts lose protected access even with an old access token.
6. Upload three distinct APKs; validate metadata/checksum and separate permanent build records. Test wrong extension, renamed ZIP without manifest, duplicate version/checksum, oversize, quota error, interrupted upload, retry and orphan cleanup.
7. Assign build → correct QA notification → download exact file → record a separate test session each time.
8. Report concurrent bugs → unique database IDs and server timestamps; refresh/relogin keeps records.
9. Pending/Not a Bug need reasons; Ready for Retest needs notes and same-app different build. Developer cannot close. QA must retest current resolution cycle; blocked must not close. Passed closes, failed reopens, every retest preserved.
10. Verify comments/status notifications, including intended recipients, read marking and inactive/member restrictions.
11. Export more than 1,000 bugs and compare every matching ID with the database. Confirm embedded history references, CSV formula defense and no permanently public evidence URLs.
12. Write/upload/version QA summaries; AI draft requires QA approval; unavailable providers preserve drafts; quota fallback stays within approved accounts.
13. Try deleting latest two/active QA APKs; deletion must be denied. Approve eligible old binary deletion, then verify bug links/reports/test history persist and download reports removed status. Test retry after partial deletion failure.
14. Verify production repository subpath, Auth redirects and recovery, all desktop/mobile flows, public code secret scan and independent backup restore.

## Approval needed

Review `backend/release.sql`. The requested approval is to update **existing project ylwdxcresqbwriifsfik** with those schema, policy, grant and Storage changes while preserving existing records. This approval does not mean the unexecuted tests pass. Complete the outstanding hardening and live matrix before publishing the application.

## Latest deployment block

User approval was received. Automatic review nevertheless rejected the broad production migration again, even with a no-operational-records precondition and successful local database tests. No workaround was used and no live changes were applied. GitHub browser sign-in was verified; Git CLI authentication is unavailable. Repository naming was changed to `PMT-System.github.io` for the root website URL; frontend has not been published.
