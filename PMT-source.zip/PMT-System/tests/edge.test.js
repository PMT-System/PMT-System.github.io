import test from 'node:test';
import assert from 'node:assert/strict';
const env={SUPABASE_URL:'https://backend.test',SUPABASE_SERVICE_ROLE_KEY:'fixture-service',SUPABASE_ANON_KEY:'fixture-public',APP_ORIGIN:'https://pmt-system.github.io'};
let handler;
globalThis.Deno={env:{get:name=>env[name]},serve:fn=>handler=fn};
await import('../backend/functions/pmt-service/index.ts');
const actor={id:'11111111-1111-4111-8111-111111111111',role:'qa',is_active:true};
let providerCalls=[];
const realFetch=globalThis.fetch;
globalThis.fetch=async(url,options={})=>{
 const path=String(url);let result;
 if(path.endsWith('/auth/v1/user'))result={id:actor.id};
 else if(path.includes('/profiles?'))result=[{...actor}];
 else if(path.includes('/rpc/pmt_ai_reserve'))result=true;
 else if(path.includes('/projects?'))result=[{id:'project'}];
 else if(path.endsWith('/ai_jobs'))result=[{id:'job',kind:'bug',input:JSON.parse(options.body).input,state:'pending'}];
 else if(path.includes('/ai_jobs?'))result=[];
 else if(path.includes('api.groq.com')){providerCalls.push('groq');return Response.json({error:{message:'quota'}},{status:429});}
 else if(path.includes('generativelanguage.googleapis.com')){providerCalls.push('gemini');result={candidates:[{content:{parts:[{text:'{"title":"Login fails","missing_information":[]}'}]}}]};}
 else throw Error('Unexpected test request: '+path);
 return Response.json(result);
};
const call=(body,jwt='fixture-token',origin='https://pmt-system.github.io')=>handler(new Request('https://service.test',{method:'POST',headers:{...(jwt?{Authorization:'Bearer '+jwt}:{}),Origin:origin,'Content-Type':'application/json'},body:JSON.stringify(body)}));
test('Service rejects missing authentication and foreign origins',async()=>{assert.equal((await call({action:'status'},'')).status,401);assert.equal((await call({action:'status'},'fixture-token','https://untrusted.test')).status,403);});
test('Inactive users and non-admin account creation are denied',async()=>{actor.is_active=false;assert.equal((await call({action:'status'})).status,403);actor.is_active=true;actor.role='developer';assert.equal((await call({action:'invite'})).status,403);actor.role='qa';});
test('APK metadata rejects size above 200 MB before allocating storage',async()=>{const r=await call({action:'upload_start',metadata:{version_name:'1',version_code:1,file_name:'a.apk',file_size:201*1024*1024,sha256:'a'.repeat(64)}});assert.equal(r.status,400);});
test('AI is unavailable honestly without approved provider credentials',async()=>{const r=await call({action:'ai',kind:'bug',project_id:'project',input:'login button kam nahi kar raha'});assert.equal(r.status,503);assert.match((await r.json()).error,/paused/);});
test('AI falls back on quota exhaustion and returns a draft without saving a bug',async()=>{env.AI_PROVIDERS=JSON.stringify([{type:'groq',key:'test',model:'test',enabled:true,freeOnly:true},{type:'gemini',key:'test',model:'test',enabled:true,freeOnly:true}]);providerCalls=[];const r=await call({action:'ai',kind:'bug',project_id:'project',input:'login button kam nahi kar raha'});assert.equal(r.status,200);const body=await r.json();assert.match(body.text,/Login fails/);assert.deepEqual(providerCalls,['groq','gemini']);});
test.after(()=>globalThis.fetch=realFetch);
