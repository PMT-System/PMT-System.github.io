import test from 'node:test';
import assert from 'node:assert/strict';
// Import is DOM-safe; browser lifecycle starts only when mountChat is called.
globalThis.sessionStorage={getItem:()=>null};
const {channelLabel,messageHTML}=await import('../chat.js');
test('Team, project and direct conversations use the correct labels',()=>{
 const people=[{id:'a',full_name:'Ali'},{id:'b',full_name:'Sara'}],projects=[{id:'p',project_name:'Android QA'}];
 assert.equal(channelLabel({kind:'team'},people,projects,'a'),'Full team');
 assert.equal(channelLabel({kind:'project',project_id:'p'},people,projects,'a'),'Android QA');
 assert.equal(channelLabel({kind:'direct',user_a:'a',user_b:'b'},people,projects,'a'),'Sara');
 assert.equal(channelLabel({kind:'direct',user_a:'a',user_b:'b'},people,projects,'b'),'Ali');
});
test('Untrusted chat messages and sender names are text, not executable HTML',()=>{
 const html=messageHTML({id:'m',sender_id:'a',body:'<img src=x onerror="alert(1)">',created_at:'2026-10-16T00:00:00Z'},'a','<script>');
 assert.ok(!html.includes('<img'));assert.ok(!html.includes('<script>'));assert.match(html,/&lt;img/);assert.match(html,/PKT/);assert.match(html,/mine/);
});
